import numpy as np
from scipy.ndimage import median_filter
import os
from scipy import interpolate
import pkg_resources
import concurrent.futures as cf
import cv2 as cv
import tkinter as tk
import matplotlib.colors as colors
from fast_histogram import histogram2d
import matplotlib.pyplot as plt
from mpl_toolkits.axes_grid1 import make_axes_locatable
from scipy.signal import savgol_filter
from natsort import natsorted
import HSTI as hsti
from scipy.signal import find_peaks

#Subtrats the mean from the data, either the mean of each spectrum (axis = 's')
#or the mean of each band (axis = 'b')
def mean_center(data_cube, axis = 's'):
    if axis == 's':
        return data_cube - np.mean(data_cube, axis = 2)[:,:,np.newaxis]
    elif axis == 'b':
        return data_cube - np.mean(data_cube, axis = (0,1))
    else:
        raise Exception("Invalid input argument. Axis input argument must be either 's' or 'b'")

#Subtracts selected band from all layers in the cube
def subtract_band(data_cube, band):
    return data_cube - data_cube[:,:,band][:,:,np.newaxis]

#Subtracts mean and scales with STD - the old standardize function. Setting
#axis = 's' is the same as doing SNV (standard normal variate)
def autoscale(data_cube, axis = 's'):
    if axis == 's':
        std_cube = np.std(data_cube, axis = 2)[:,:,np.newaxis]
        std_cube[std_cube < 1e-6] = np.nan
        return (data_cube - np.mean(data_cube, axis = 2)[:,:,np.newaxis])/std_cube
    elif axis == 'b':
        return (data_cube - np.mean(data_cube, axis = (0,1)))/np.std(data_cube, axis = (0,1))
    else:
        raise Exception("Invalid input argument. Axis input argument must be either 's' or 'b'")


def norm_normalization(data_cube, order, axis = 's'):
    if axis == 's':
        return data_cube/np.linalg.norm(data_cube, ord = order, axis = 2)[:,:,np.newaxis]
    elif axis == 'b':
        return data_cube/np.linalg.norm(data_cube, ord = order, axis = (0,1))
    else:
        raise Exception("Invalid input argument. Axis input argument must be either 's' or 'b'")

def debend_single_band(selections, img, interp_spec, mirror_sep):
    interp_img = np.zeros_like(img)
    interp_img[selections[0]] = img[selections[0]]
    for i in range(len(selections) - 1):
        interp_img[selections[i+1]] = interp_spec[i+1](mirror_sep)
    return interp_img

def debend(cube, central_mirror_sep):
    print('Debending cube')
    N = 100
    f_length = 35e-3 #Focal length
    px_pitch = 17e-6 #Pixel pitch
    p_x = np.arange(cube.shape[1])
    p_y = np.arange(cube.shape[0])
    P_x, P_y = np.meshgrid(p_x, p_y)
    r = np.sqrt(((P_x - 430)**2 + (P_y - 505)**2)*px_pitch**2)
    theta = np.arctan(r/f_length)
    #Fitting parameters for use later
    [a, b] = [-1.24875814e-04,  2.37220232e-05]

    masks = []
    #THETA hold the angles of each boundary between each ring
    THETA = np.linspace(0, np.max(theta), N+1)
    THETA = np.delete(THETA, 0)
    #THETA = 0 is deleted because this will result in a circle with an area of 0
    # The innermost 'ring' is just a circle and this mask is therefore a special case
    masks.append(theta <= THETA[0])
    #The rest of the masks are generated
    for i in range(N-1):
        masks.append((theta > THETA[i]) & (theta <=THETA[i+1]))

    mirror_sep_axes = []
    mirror_sep_axes.append(central_mirror_sep)
    for i in range(N-1):
        correction = central_mirror_sep*(a * np.rad2deg(THETA[i+1])**2 + b * np.rad2deg(THETA[i+1]))
        mirror_sep_axes.append(central_mirror_sep + correction)

    interpolated_cube = np.zeros_like(cube)
    interpolated_spectra = []
    for i in range(N):
        interpolated_spectra.append(interpolate.interp1d(mirror_sep_axes[i], cube[masks[i], :], fill_value = 'extrapolate'))

    mask_lst, img_lst, interp_spec_lst, mirror_sep_lst = [], [], [], []
    for i in range(cube.shape[2]):
        mask_lst.append(masks)
        img_lst.append(cube[:,:,i])
        interp_spec_lst.append(interpolated_spectra)
        mirror_sep_lst.append(mirror_sep_axes[0][i])

    with cf.ThreadPoolExecutor() as executor:
        results = executor.map(debend_single_band, mask_lst, img_lst, interp_spec_lst, mirror_sep_lst)

    debent = np.zeros_like(cube)
    for i, result in enumerate(results):
        debent[:,:,i] = result

    return debent

def load_cube(directory):
    if '.pam' in directory:
        header_info = {}
        data_start_pos = 0
        
        with open(directory, 'rb') as f:
            # Read line by line until we find "ENDHDR"
            while True:
                line = f.readline().decode('ascii').strip()
                if line == "ENDHDR":
                    # Mark the current file position as the start of data
                    data_start_pos = f.tell()
                    break
                
                # Parse the header line
                if line.startswith("WIDTH"):
                    header_info['width'] = int(line.split()[1])
                elif line.startswith("HEIGHT"):
                    header_info['height'] = int(line.split()[1])
                elif line.startswith("DEPTH"):
                    header_info['depth'] = int(line.split()[1])
                elif line.startswith("MAXVAL"):
                    header_info['maxval'] = int(line.split()[1])
                
            # Move to the data start position
            f.seek(data_start_pos)

            # Read the binary data into an array
            width = header_info['width']
            height = header_info['height']
            depth = header_info['depth']

            # Assuming the data is stored as 16-bit unsigned integers (based on MAXVAL=65535)
            if header_info['maxval'] > 255:
                cube = np.fromfile(f, dtype=np.uint16).reshape((height, width, depth))
            else:
                cube = np.fromfile(f, dtype=np.uint8).reshape((width, depth, height), order = 'F')
            cube = cube.astype('float64')
    elif '.npy' in directory:
        cube = np.load(directory)
        cube = cube.astype(float)
    else:
        file_list = [x for x in os.listdir(f'{directory}/images/capture') if ".ppm" and not "RGB" in x] 
        file_list = natsorted(file_list)
        cube = []
        for file in file_list: #load bands into data structure
            cube.append(np.rot90(cv.imread(f'{directory}/images/capture/{file}',cv.IMREAD_ANYDEPTH)))
        cube = np.array(cube, dtype = 'float64')
        cube = np.moveaxis(cube, 0, 2) #Rearranges the array to required shape
    return cube

def correct_laser_pixels(img_cube):
    mask = np.zeros([10, 10], dtype = bool)
    mask[2,4:7] = True
    mask[3,3:8] = True
    mask[4:7,2:8] = True
    mask[7,3:7] = True
    xx, yy = np.meshgrid(np.arange(0, 10), np.arange(0, 10))
    bad_x = xx[~mask]
    bad_y = yy[~mask]
    for i in range(img_cube.shape[2]):
        temp = img_cube[471:481,381:391,i]
        img_cube[471:481,381:391,i] = interpolate.griddata((bad_x, bad_y), temp[~mask].ravel(), (xx, yy), method = 'linear')
    return img_cube

def correct_laser_pixels_large(img_cube):
    mask = np.zeros([16, 16], dtype = bool)
    mask[2:-2,2:-2] = True
    xx, yy = np.meshgrid(np.arange(0, 16), np.arange(0, 16))
    bad_x = xx[~mask]
    bad_y = yy[~mask]
    for i in range(img_cube.shape[2]):
        temp = img_cube[468:484,378:394,i]
        img_cube[468:484,378:394,i] = interpolate.griddata((bad_x, bad_y), temp[~mask].ravel(), (xx, yy), method = 'linear')
    return img_cube

def remove_vignette(img_cube):

    #Image must have dimensions 1024x768. This function does not calculate
    #vignette based on the image itself. It asumes that the image is taken using
    #a specific camera and applies a predetermined vignetting correction.
    #This function can both be used on single images as well as entire cubes

    resource_package = __name__
    resource_path = '/'.join(('data_files', 'vignetting_profile.txt'))  # Do not use os.path.join()
    path = pkg_resources.resource_stream(resource_package, resource_path)
    vignette = np.loadtxt(path)

    vignette_cube = np.zeros_like(img_cube)

    if len(img_cube.shape) == 3:
        vignette_cube = vignette
        vignette_cube = vignette_cube[:,:,np.newaxis]
        vignette_cube = np.repeat(vignette_cube, img_cube.shape[2], axis = 2)
        devignetted_cube = img_cube/vignette_cube
    elif len(img_cube.shape) == 2:
        devignetted_cube = img_cube/vignette

    return devignetted_cube


#Function for partitioning selection into rectangles. It searches for continuous patches of 0's in array
#https://www.geeksforgeeks.org/find-rectangles-filled-0/
def findend(i,j,a,output,index):
    x = len(a)
    y = len(a[0])
    # flag to check column edge case,
    # initializing with 0
    flagc = 0
    # flag to check row edge case,
    # initializing with 0
    flagr = 0
    for m in range(i,x):
        # loop breaks where first 1 encounters
        if a[m][j] == 1:
            flagr = 1 # set the flag
            break
        # pass because already processed
        if a[m][j] == 5:
            pass
        for n in range(j, y):
            # loop breaks where first 1 encounters
            if a[m][n] == 1:
                flagc = 1 # set the flag
                break
            # fill rectangle elements with any
            # number so that we can exclude
            # next time
            a[m][n] = 5
    if flagr == 1:
        output[index].append( m-1)
    else:
        # when end point touch the boundary
        output[index].append(m)

    if flagc == 1:
        output[index].append(n-1)
    else:
        # when end point touch the boundary
        output[index].append(n)

#Works with findend() to find the corner coordinates of rectangles in selection
#This function splits a boolean array up into a number of rectangles. The corner coordinates
#of each rectangle is stored in the output list.
def get_rectangle_coordinates(a):
    # retrieving the column size of array
    size_of_array = len(a)
    # output array where we are going
    # to store our output
    output = []
    # It will be used for storing start
    # and end location in the same index
    index = -1
    for i in range(0,size_of_array):
        for j in range(0, len(a[0])):
            if a[i][j] == 0:
                # storing initial position
                # of rectangle
                output.append([i, j])
                # will be used for the
                # last position
                index = index + 1
                findend(i, j, a, output, index)
    return output

def apply_NUC(cube, directory, camera_ID):
    #Calculate mean sensor temperature during capture

    with open(f"{directory}/output.txt", 'r') as file:
        lines = file.readlines()
        temperature_lst = []
        for line in lines:
            if (len(line.split()) == 13) or (len(line.split()) == 10):
                temperature_lst.append(int(line.split()[6])/1000)
        sensor_temp = np.mean(temperature_lst)
        if len(lines[-1].split()) == 13:
            GSK = int(lines[-1].split()[10])
        else:
            GSK = tk.simpledialog.askinteger(title = 'Input box', prompt = 'Input GSK setting')

    offset_coefs = np.load(f'data_files/NUC/{camera_ID}/offset_coefs_1st_order.npy', allow_pickle = True)
    slope_coefs = np.load(f'data_files/NUC/{camera_ID}/slope_coefs_1st_order.npy', allow_pickle = True)

    # M = np.array([[GSK, GSK**2, GSK**3, sensor_temp, sensor_temp**2, sensor_temp**3, 1]]).T
    M = np.array([[GSK, sensor_temp, 1]]).T
    offsets = offset_coefs@M
    slopes = slope_coefs@M

    mean_offset = np.nanmean(offsets)
    mean_slopes = np.nanmean(slopes)

    offset_correction = - mean_slopes*offsets/slopes + mean_offset
    slope_correction = (mean_slopes - slopes)/slopes

    offset_matrix = offset_correction.reshape([cube.shape[0], cube.shape[1]], order = 'C')
    slope_matrix = slope_correction.reshape([cube.shape[0], cube.shape[1]], order = 'C')

    temp_cube = np.copy(cube)
    for i in range(temp_cube.shape[2]):
        temp_cube[:,:,i] = temp_cube[:,:,i] + temp_cube[:,:,i]*slope_matrix + offset_matrix

    return temp_cube

def relative_mirror_separation(directory):
    diode = hsti.import_output(f'{directory}/output.txt')
    I0 = savgol_filter(diode[-1][:,3], 5, 2, 0)
    I0 = I0-np.min(I0)
    I0 = I0/np.max(I0)
    I1 = savgol_filter(diode[-1][:,4], 5, 2, 0)
    I1 = I1-np.min(I1)
    I1 = I1/np.max(I1)
    I2 = savgol_filter(diode[-1][:,5], 5, 2, 0)
    I2 = I2-np.min(I2)
    I2 = I2/np.max(I2) 

    steps = np.arange(len(I0))
    peaks_I0_idx, _ = find_peaks(I0, prominence=1e-1)
    troughs_I0_idx, _ = find_peaks(-I0, prominence=1e-1)
    peaks_I1_idx, _ = find_peaks(I1, prominence=1e-1)
    troughs_I1_idx, _ = find_peaks(-I1, prominence=1e-1)
    peaks_I2_idx, _ = find_peaks(I2, prominence=1e-1)
    troughs_I2_idx, _ = find_peaks(-I2, prominence=1e-1)

    idx0 = np.sort(np.concatenate((peaks_I0_idx, troughs_I0_idx)))
    idx1 = np.sort(np.concatenate((peaks_I1_idx, troughs_I1_idx)))
    idx2 = np.sort(np.concatenate((peaks_I2_idx, troughs_I2_idx)))

    window_len = 10
    all_idx_in_range = np.array([])
    counter = 0
    while len(all_idx_in_range) < 3:
        idx0_in_range = idx0[(idx0>=steps[counter]) & (idx0 < steps[counter+window_len])]
        idx1_in_range = idx1[(idx1>=steps[counter]) & (idx1 < steps[counter+window_len])]
        idx2_in_range = idx2[(idx2>=steps[counter]) & (idx2 < steps[counter+window_len])]
        all_idx_in_range = np.concatenate((idx0_in_range, idx1_in_range, idx2_in_range))
        counter += 1
    print(f'Starting step for aligned interferograms: diode 0: {all_idx_in_range[0]}, diode 1: {all_idx_in_range[1]}, and diode 2: {all_idx_in_range[2]}')
    idx0 = idx0[idx0 >= all_idx_in_range[0]]
    idx1 = idx1[idx1 >= all_idx_in_range[1]]
    idx2 = idx2[idx2 >= all_idx_in_range[2]]

    dx = 686e-9/4 #dx = (lam/cos(theta))/4 - found using bandpass filters

    x0 = np.arange(len(idx0))*dx
    x1 = np.arange(len(idx1))*dx
    x2 = np.arange(len(idx2))*dx

    p0 = np.poly1d(np.polyfit(idx0, x0, 3))
    p1 = np.poly1d(np.polyfit(idx1, x1, 3))
    p2 = np.poly1d(np.polyfit(idx2, x2, 3))

    R_sqr0 = 1 - np.sum((x0 - p0(idx0))**2)/np.sum((x0 - np.mean(p0(idx0)))**2)
    R_sqr1 = 1 - np.sum((x1 - p1(idx1))**2)/np.sum((x1 - np.mean(p1(idx1)))**2)
    R_sqr2 = 1 - np.sum((x2 - p2(idx2))**2)/np.sum((x2 - np.mean(p2(idx2)))**2)
    print('Diode 0 fit: R² = ' + str(R_sqr0))
    print('Diode 1 fit: R² = ' + str(R_sqr1))
    print('Diode 2 fit: R² = ' + str(R_sqr2))

    p_comb = np.poly1d(np.polyfit(idx2, x2, 3))
    p_comb.coef[0] = (p0.coef[0]+p1.coef[0]+p2.coef[0])/3
    p_comb.coef[1] = (p0.coef[1]+p1.coef[1]+p2.coef[1])/3
    p_comb.coef[2] = (p0.coef[2]+p1.coef[2]+p2.coef[2])/3
    p_comb.coef[3] = (p0.coef[3]+p1.coef[3]+p2.coef[3])/3

    x_comb = np.concatenate((x0,x1,x2))
    idx_comb = np.concatenate((idx0,idx1,idx2))
    R_sqr_cmb = 1 - np.sum((x_comb - p_comb(idx_comb))**2)/np.sum((x_comb - np.mean(p_comb(idx_comb)))**2)
    print(R_sqr_cmb)

    file_list = [x for x in os.listdir(f'{directory}/images/capture') if ".ppm" and not "RGB" in x] 
    file_list = natsorted(file_list)
    cube_steps = [int(s.split('step')[1].split('.ppm')[0]) for s in file_list]

    return p_comb(cube_steps)


def clear_terminal():
    # for windows
    if os.name == 'nt':
        _ = os.system('cls')
    # for mac and linux(here, os.name is 'posix')
    else:
        _ = os.system('clear')
