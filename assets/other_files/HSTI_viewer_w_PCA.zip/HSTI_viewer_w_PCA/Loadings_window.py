import numpy as np
import tkinter as tk
import matplotlib
matplotlib.use("TkAgg")
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
from matplotlib.figure import Figure
from matplotlib import gridspec
from mpl_toolkits.axes_grid1 import make_axes_locatable
import matplotlib.pyplot as plt
import cv2 as cv
from HSTI_Class import HSTI
import Basic_Math as bm
from fast_histogram import histogram2d
import matplotlib.colors as colors
import time


class loadings_window(tk.Frame):

    ########## Setup window and initiate member variables ##########
    def __init__(self, the_window, the_app):

        super().__init__(width = the_window.winfo_screenwidth()//2, height = the_window.winfo_screenheight()//2)
        self.bck = 'white'
        self.canvas = tk.Canvas(self, width = the_window.winfo_screenwidth()//2, height = the_window.winfo_screenheight()//2, background = self.bck)
        self['bg'] = self.bck
        self.parent = the_window
        self.app = the_app
        self.width = self.app.window_width//2
        self.height = self.app.window_height//8
        self.window = tk.Toplevel(self.parent, bg = self.bck)
        self.window.title('Loadings window')
        self.DPI = 100
        self.min_dim = min([self.app.window_width, self.app.window_height])
        self.fig = Figure(figsize=(0.8*16*self.min_dim/900, 0.70*self.min_dim/100), dpi = self.DPI)
        gs = gridspec.GridSpec(1, 1) #set size ratio of the subfigures
        self.ax1 = self.fig.add_subplot(gs[0,0])
        self.ax1.set_xlim([np.min(self.app.hsti.x_axis),np.max(self.app.hsti.x_axis)])
        self.ax1.set_xlabel(self.app.hsti.x_axis_label)
        self.ax1.set_ylabel('Loading intensity [a.u.]')
        self.ax1.grid()

        self.window.columnconfigure(0, weight = 1)
        self.window.columnconfigure(1, weight = 1)
        self.window.columnconfigure(2, weight = 1)

        self.fig_TkAgg = FigureCanvasTkAgg(self.fig, master = self.window)
        self.fig_TkAgg.draw()
        self.fig_TkAgg.get_tk_widget().grid(row=0,column=0, columnspan = 3)

        self.lb_all_loadings_label = tk.Label(self.window, text = "Loadings", bg = self.bck)
        self.lb_all_loadings_label.grid(row = 1, column = 1)
        self.lb_all_loadings = tk.Listbox(self.window, height = 5, selectmode = "multiple")
        self.lb_all_loadings.grid(row = 2, column = 1, sticky = 'nsew')
        self.lb_all_loadings.bind('<<ListboxSelect>>', self.plot_loadings)

        options = []
        for i in range(self.parent.loadings.shape[1]):
            options.append(f'Loadings, PC {i+1}, {round(self.parent.pct_expl_var[i],2)}%')
            self.lb_all_loadings.insert("end",options[-1])

# Go through all selected elements and plot them
    def plot_loadings(self, event):
            self.ax1.cla()
            item_idx = [idx for idx in self.lb_all_loadings.curselection()]
            for idx in item_idx:
                self.ax1.plot(self.app.hsti.x_axis, self.parent.loadings[:,idx], label = self.lb_all_loadings.get(idx))
            self.ax1.grid()
            if len(item_idx) > 0:
                self.ax1.legend()
            else:
                self.ax1.set_xlim([np.min(self.app.hsti.x_axis),np.max(self.app.hsti.x_axis)])
            self.ax1.set_xlabel(self.app.hsti.x_axis_label)
            self.ax1.set_ylabel('Loading intensity [a.u.]')
            self.fig_TkAgg.draw()
