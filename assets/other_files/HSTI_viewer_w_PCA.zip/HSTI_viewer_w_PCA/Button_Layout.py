import tkinter as tk
from PCA_window import pca_window
from Viewer_Canvas import Viewer
from HSTI_Class import HSTI
from tkinter import filedialog
import Basic_Math as bm
import numpy as np
import cv2 as cv
import os
from tkinter import colorchooser
from tkinter import messagebox as mb
from PIL import Image, ImageTk
from matplotlib.animation import FuncAnimation, writers
from matplotlib.figure import Figure
from matplotlib import gridspec
from mpl_toolkits.axes_grid1 import make_axes_locatable
import matplotlib.pyplot as plt
import matplotlib.patches as patch
from RangeSlider.RangeSlider import RangeSliderH
from scipy.signal import savgol_filter
import concurrent.futures as cf
from scipy.ndimage import median_filter
from Camera_Import_Dialog import Camera_Dialog
import HSTI as hsti # HSTI module - NOT the class

class Buttons(tk.Frame):
    #Draw all interactive elements in bottom part of the frame. Bottons and sliders
    def __init__(self, the_window, the_app):
        bck = 'white'
        self.parent = the_window
        self.app = the_app
        self.width = self.app.window_width
        self.height = self.app.window_height//3
        super().__init__(width = self.width, height = self.height)
        self['bg'] = bck

        vpad = self['height']//50

        self.columnconfigure(0, weight = 1)
        self.columnconfigure(1, weight = 2)
        self.columnconfigure(2, weight = 2)
        self.columnconfigure(3, weight = 2)
        self.columnconfigure(4, weight = 2)
        self.columnconfigure(5, weight = 2)
        self.columnconfigure(6, weight = 2)
        self.columnconfigure(7, weight = 1)

        self.band_slider_title = tk.Label(self, text = "Band number", bg = bck)
        self.band_slider_title.grid(row = 0, column = 1)

        self.radius_slider_title = tk.Label(self, text = "Radius", bg = bck)
        self.radius_slider_title.grid(row = 0, column = 4, columnspan = 3)

        self.band_slider = tk.Scale(self, from_ = 1, to = self.app.hsti.cube.shape[2], orient=tk.HORIZONTAL,\
        length = self['width']//4, bd = 0, bg = bck, command = self.update_band)
        self.band_slider.set(self.app.hsti.cube.shape[2]//3)
        self.band_slider.grid(row = 1, column = 1, sticky = 'nsew')

        self.clear_selection_btn = tk.Button(self, text = 'Clear selection', bg = bck, command = self.clear_map)
        self.clear_selection_btn.grid(row = 1, column = 2)

        self.color_picker_btn  = tk.Button(self, text = 'Pick color', bg = bck, command = self.choose_color)
        self.color_picker_btn.grid(row = 1, column = 3)

        self.radius_slider = tk.Scale(self, from_ = 1, to = 100, length = self['width']//4, orient=tk.HORIZONTAL, \
        bd = 0, bg = bck)
        self.radius_slider.set(5)
        self.radius_slider.grid(row = 1, column = 4, columnspan = 3, sticky = 'nsew')

        self.rowconfigure(2, minsize = vpad) # Insert empty row

        self.save_img_btn = tk.Button(self, text = 'Save current band', bg = bck, command = self.save_current_band)
        self.save_img_btn.grid(row = 3, column = 2)

        self.save_animation_btn  = tk.Button(self, text = 'Save animation', bg = bck, command = self.save_animation)
        self.save_animation_btn .grid(row = 3, column = 3)

        self.alpha_slider_title = tk.Label(self, text = "Selection opacity", bg = bck)
        self.alpha_slider_title.grid(row = 3, column = 4, columnspan = 3)

        self.save_fig_btn = tk.Button(self, text = 'Save figure', bg = bck, command = self.save_figure)
        self.save_fig_btn.grid(row = 4, column = 2)

        self.save_specs_btn = tk.Button(self, text = 'Save spectra', bg = bck, command = self.save_specs)
        self.save_specs_btn.grid(row = 4, column = 3)

        self.alpha_slider = tk.Scale(self, from_ = 0, to = 255, length = self['width']//4, orient=tk.HORIZONTAL, \
        bd = 0, bg = bck, command = self.update_alpha)
        self.alpha_slider.set(128)
        self.alpha_slider.grid(row = 4, column = 4, columnspan = 3, sticky = 'nsew')

        self.C_x_axis = tk.BooleanVar()
        self.x_axis_checkbox = tk.Checkbutton(self, text="Select calibrated x axis", variable = self.C_x_axis, command = self.update_x_axis, bg = bck)
        self.x_axis_checkbox.grid(row = 5, column = 3)

        self.C_debend = tk.BooleanVar()
        self.debend_checkbox = tk.Checkbutton(self, text="Debend cube", variable = self.C_debend, command = self.debend_cube, bg = bck)
        self.debend_checkbox.grid(row = 5, column = 2)

        self.C_clim = tk.BooleanVar()
        self.clim_checkbox = tk.Checkbutton(self, text="Manual color limits", variable = self.C_clim, command = self.update_clim_chk_bx, bg = bck)
        self.clim_checkbox.grid(row = 5, column = 4, columnspan = 1)

        self.invert_selection_btn = tk.Button(self, text = 'Invert selection', bg = bck, command = self.invert_selection)
        self.invert_selection_btn.grid(row = 6, column = 2)

        self.pca_btn = tk.Button(self, text = 'Open PCA window', bg = bck, command = lambda: pca_window(self.parent, self.app))
        self.pca_btn.grid(row = 7, column = 2)

        self.select_directory_btn = tk.Button(self, text = 'Select directory', bg = bck, command = lambda: self.select_directory())
        self.select_directory_btn.grid(row = 6, column = 3)

        self.select_file_btn = tk.Button(self, text = 'Select file', bg = bck, command = lambda: self.select_file())
        self.select_file_btn.grid(row = 7, column = 3)

        self.clim_min = tk.DoubleVar()  #left handle variable
        self.clim_max = tk.DoubleVar()  #right handle variable
        self.clim_slider = RangeSliderH(self , [self.clim_min, self.clim_max], Width = self['width']//4, \
        Height = self['height']//5, bar_radius = 4, padX = 120, bgColor = '#ffffff',\
        min_val = 0, max_val = 1, valueSide = 'BOTTOM', font_size = int(self.app.viewer.DPI/72*(self.app.viewer.min_dim/1440)*8))   #horizontal
        self.clim_min.trace('w', self.manual_clim)
        self.clim_slider.grid(row = 6, column = 4, columnspan = 1)

        self.remove_data_btn = tk.Button(self, text = 'Remove data', bg = bck, command = self.remove_data)
        self.remove_data_btn.grid(row = 7, column = 4, columnspan = 1)

        self.flip_data_lr_btn = tk.Button(self, text = 'Flip LR', bg = bck, command = self.flip_left_right)
        self.flip_data_lr_btn.grid(row = 7, column = 5)

        self.flip_data_ud_btn = tk.Button(self, text = 'Flip UD', bg = bck, command = self.flip_up_down)
        self.flip_data_ud_btn.grid(row = 7, column = 6)

        self.sub_frame = tk.Frame(self, height = self.height//300, width = self.width//4, bg = bck)
        self.sub_frame.grid(row = 3, column = 1, rowspan = 5, sticky = 'nsew')

        self.rowconfigure(8, minsize = vpad) # Insert empty row


#### Select preprocessing steps ###

        self.sub_frame.columnconfigure(0, weight=1)
        self.sub_frame.columnconfigure(1, weight=1)
        self.sub_frame.columnconfigure(2, weight=1)
        self.sub_frame.columnconfigure(3, weight=1)

        self.options = [
        "Apply NUC",
        "Autoscale",
        "Convert to wavelength",
        "Correct laser spot",
        "Correct laser spot LARGE", 
        "Mean center bands",
        "Mean center spectra",
        "Normalize band norms",
        "Normalize by reference spectrum",
        "Normalize cube",
        "Normalize spectra",
        "Normalize spectra norms",
        "Savitzky-Golay filter",
        "Set first band to 0",
        "Spatial median filter",
        "Standard Normal Variate",
        "Subtract TMM reference spectrum",
        "Use selection as reference spectrum"
        ]

        self.lb_options = tk.Listbox(self.sub_frame, height = 2)
        self.lb_options.grid(row = 0, column = 0, columnspan = 2, sticky = 'nsew')
        self.lb_options.bind('<Double-1>', self.add_preprocessing)
        self.lb_options.bind('<Return>', self.add_preprocessing)


        self.lb_preprocessing = tk.Listbox(self.sub_frame)
        self.lb_preprocessing.grid(row = 0, column = 2, columnspan = 2, sticky = 'nsew')
        self.lb_preprocessing.bind('<Double-1>', self.delete_preprocessing)
        self.lb_preprocessing.bind('<Return>', self.delete_preprocessing)


        #populate list of preprocessing options
        for item in self.options:
            self.lb_options.insert("end",item)

    #Based on the selection in the list box, the preprocessing is performed
    def perform_preprocessing(self, selection):
        if selection == "Apply NUC":
            if self.app.hsti.camera_ID == None:
                dialog = Camera_Dialog(title="Dropdown dialog", parent=self.parent)
                self.app.hsti.camera_ID = dialog.camera_ID
            self.app.hsti.cube = bm.apply_NUC(self.app.hsti.cube, self.app.hsti.path, self.app.hsti.camera_ID)

        elif selection == "Autoscale":
            self.app.hsti.cube = hsti.autoscale(self.app.hsti.cube, axis = 'b')

        elif selection == "Convert to wavelength":
            self.m2w()
        
        elif selection == "Correct laser spot":
            self.app.hsti.cube = bm.correct_laser_pixels(self.app.hsti.cube)

        elif selection == "Correct laser spot LARGE":
            self.app.hsti.cube = bm.correct_laser_pixels_large(self.app.hsti.cube)

        elif selection == "Mean center bands":
            self.app.hsti.cube = hsti.mean_center(self.app.hsti.cube, axis = 'b')

        elif selection == "Mean center spectra":
            self.app.hsti.cube = hsti.mean_center(self.app.hsti.cube, axis = 's')
        
        elif selection == "Normalize band norms":
            self.app.hsti.cube = hsti.norm_normalization(self.app.hsti.cube, order = 1, axis = 's')
        
        elif selection == "Normalize by reference spectrum":
            self.divide_by_ref_spec()

        elif selection == "Normalize cube":
            self.app.hsti.cube = hsti.normalize_cube(self.app.hsti.cube)

        elif selection == "Normalize spectra":
            self.app.hsti.cube = hsti.normalize(self.app.hsti.cube, 's')

        elif selection == "Normalize spectra norms":
            self.app.hsti.cube = hsti.norm_normalization(self.app.hsti.cube, order = 1, axis = 'b')
        
        elif selection == "Spatial median filter":
            self.app.hsti.cube = self.median_filter_cube(self.app.hsti.cube, self.lb_preprocessing)
        
        elif selection == "Set first band to 0":
            self.app.hsti.cube = hsti.subtract_band(self.app.hsti.cube, 0)

        elif selection == "Standard Normal Variate":
            self.app.hsti.cube = hsti.autoscale(self.app.hsti.cube, axis = 's')
        
        elif selection == "Savitzky-Golay filter":
            self.app.hsti.cube = self.savgol(self.app.hsti.cube, self.lb_preprocessing)
        
        elif selection == "Subtract TMM reference spectrum":
            self.subtract_ref_spec()

        elif selection == "Use selection as reference spectrum":
            self.reference_spec_from_selection()
            


                # FPI_obj = hsti.FPI()
    #Function for adding preprocessing steps to the list by double clicking.
    #Items are added to the end of the list, and both plots and clim slider are updated.
    def add_preprocessing(self, event):
        self.lb_preprocessing.insert("end", self.lb_options.get("anchor"))
        self.perform_preprocessing(self.lb_preprocessing.get("end"))
        self.draw_new_range_slider(np.nanmin(self.app.hsti.cube), np.nanmax(self.app.hsti.cube))
        self.app.viewer.display_band()
        self.app.viewer.calc_spec()
        self.app.viewer.plot_spec()

    #Delete items already added to preprocessing list by double clicking. This
    #requires all preprocessing steps to be repeated in order
    def delete_preprocessing(self, event):
        anchor = self.lb_preprocessing.get("anchor")
        if anchor == "Savitzky-Golay filter":
            self.app.hsti.savgol_w_length = []
            self.app.hsti.savgol_p_order = []
            self.app.hsti.savgol_deriv = []
        elif anchor == "Use selection as reference spectrum":
            self.app.hsti.ref_spec_from_selection = None
        elif anchor == "Spatial median filter":
            self.app.hsti.spatial_median_size = []
        elif anchor == "Convert to wavelength":
            self.app.hsti.cube = self.app.hsti.ms_cube
            self.band_slider.configure(to = self.app.hsti.cube.shape[2])
            self.update_x_axis()
            self.app.viewer.display_band()
            self.app.viewer.plot_spec()

        self.lb_preprocessing.delete("anchor")
        self.app.hsti.cube = self.app.hsti.raw_cube
        for idx, entry in enumerate(self.lb_preprocessing.get(0, "end")):
            self.perform_preprocessing(entry)
        self.draw_new_range_slider(np.nanmin(self.app.hsti.cube), np.nanmax(self.app.hsti.cube))
        self.app.viewer.display_band()
        self.app.viewer.calc_spec()
        self.app.viewer.plot_spec()

    # I can simpelthen not find a better way of dynamically updating the slider positions
    # than to simply redraw everything each time...
    def draw_new_range_slider(self, cmin, cmax):
        self.clim_min = tk.DoubleVar()  #left handle variable
        self.clim_max = tk.DoubleVar()  #right handle variable
        self.clim_slider = RangeSliderH(self , [self.clim_min, self.clim_max], Width = self['width']//4, \
        Height = self['height']//5, bar_radius = 4, padX = 120, bgColor = '#ffffff',\
        min_val = cmin, max_val = cmax, valueSide = 'BOTTOM', font_size = int(self.app.viewer.DPI/72*(self.app.viewer.min_dim/1440)*8))   #horizontal
        self.clim_min.trace('w', self.manual_clim)
        self.clim_slider.grid(row = 6, column = 4)

    #Calls debend_cube from Basic_Math when checkbox is clicked
    def debend_cube(self):
        if self.app.hsti.calibrated_x_axis is False:
            self.C_x_axis.set(True)
            self.update_x_axis()

        if self.app.hsti.calibrated_x_axis is True:
            self.debend_checkbox.configure(state=tk.DISABLED)
            # self.x_axis_checkbox.configure(state=tk.DISABLED)
            self.app.hsti.raw_cube = bm.debend(self.app.hsti.raw_cube, self.app.hsti.x_axis)
            self.app.hsti.cube = self.app.hsti.raw_cube
            for idx, entry in enumerate(self.lb_preprocessing.get(0, "end")):
                self.perform_preprocessing(entry)

            self.draw_new_range_slider(np.nanmin(self.app.hsti.cube), np.nanmax(self.app.hsti.cube))
            self.app.viewer.display_band()
            self.app.viewer.calc_spec()
            self.app.viewer.plot_spec()
            bm.clear_terminal()
            print('!!!All done!!!')
        else:
            self.C_x_axis.set(0)
            self.C_debend.set(0)

    #Prompts user for directory where the data cube is stored
    def select_directory(self):
        temp_path = filedialog.askdirectory(parent = self.parent, initialdir = self.app.hsti.path, title = "Choose Directory")
        if (temp_path != ()) and (temp_path != '\n') and (temp_path != ''):
            self.app.hsti.path = temp_path
            if os.path.isdir(self.app.hsti.path + '/images/capture'):
                self.load_HSTI(self.app.hsti.path)
            else:
                mb.showerror('No such directroy', 'Please select directory containing "/images/capture"')
        return

    #Prompts user for directory where the data cube is stored
    def select_file(self):
        temp_path = filedialog.askopenfilename(parent = self.parent, initialdir = self.app.hsti.path, title = "Choose .pam file")
        if (temp_path != ()) and (temp_path != '\n') and (temp_path != ''):
            if os.path.isfile(temp_path):
                self.load_HSTI(temp_path)
            else:
                mb.showerror('Please choose a .pam file instead')
            self.app.hsti.path = temp_path.rsplit('/', 1)[0]
        return

    #Loads data cube based on directory
    def load_HSTI(self, directory):
        #initiate 3D matrix for all bands
        # self.app.hsti.raw_cube = bm.load_cube(directory)
        temp_cube = bm.load_cube(directory)
        self.app.hsti = HSTI(temp_cube)
        self.app.hsti.path = directory.split('.pam')[0]
        # self.app.hsti.cube = self.app.hsti.raw_cube
        self.app.hsti.x_axis = np.linspace(1, self.app.hsti.cube.shape[2], self.app.hsti.cube.shape[2])
        self.clim_slider.min_val = np.nanmin(self.app.hsti.cube)
        self.clim_slider.max_val = np.nanmax(self.app.hsti.cube)

        self.app.title = f"Newtec HSTI Viewer: {self.app.hsti.path}"
        self.parent.title(self.app.title)
        self.draw_new_range_slider(np.nanmin(self.app.hsti.cube), np.nanmax(self.app.hsti.cube))

        self.reset_all()
        bm.clear_terminal()

        self.app.viewer.initialize_plots()

        print('!!!!All done!!!!')




    #Function which forces viewer to update current image
    def update_band(self, slider_val):
        self.app.viewer.current_band = int(slider_val) - 1
        self.app.viewer.display_band()

    #Updates the mask overlay
    def update_alpha(self, slider_val):
        self.app.hsti.alpha[self.app.hsti.bool_map == 1] = int(slider_val)
        self.app.hsti.mask_w_alpha[:,:,3] = self.app.hsti.alpha
        self.app.viewer.display_mask()

    #Controls the bounds of the color scale based on double slider
    def manual_clim(self, var, index, mode):
        temp = self.clim_slider.getValues()
        if self.C_clim.get():
            self.app.viewer.im1.set_clim(vmin = temp[0], vmax = temp[1])
            self.app.viewer.display_band()
        else:
            self.app.viewer.im1.set_clim(vmin = np.nanmin(self.app.hsti.cube[:,:,self.app.viewer.current_band]),\
            vmax = np.nanmax(self.app.hsti.cube[:,:,self.app.viewer.current_band]))
            self.app.viewer.display_band()

    #Updates viewer when check box controlling color limits is checked
    def update_clim_chk_bx(self):
        if self.C_clim.get():
            temp = self.clim_slider.getValues()
            self.app.viewer.im1.set_clim(vmin = temp[0], vmax = temp[1])
            self.app.viewer.display_band()
        else:
            self.app.viewer.im1.set_clim(vmin = np.nanmin(self.app.hsti.cube[:,:,self.app.viewer.current_band]),\
            vmax = np.nanmax(self.app.hsti.cube[:,:,self.app.viewer.current_band]))
            self.app.viewer.display_band()

    #Prompts user to find file containing mirror separation axis
    def update_x_axis(self):
        if self.C_x_axis.get():
            self.show_x_axis_dialog(self.parent, self.app)
        else:
            self.app.hsti.x_axis = np.linspace(1, self.app.hsti.cube.shape[2] + 1, self.app.hsti.cube.shape[2])
            self.app.hsti.x_axis_label = 'Band number [#]'
            self.app.viewer.display_band()
            self.app.viewer.plot_spec()

    #clears overlay
    def clear_map(self):
        self.app.hsti.mask_no_alpha = np.ones_like(self.app.hsti.mask_no_alpha, dtype=np.uint8)
        self.app.hsti.alpha = np.zeros_like(self.app.hsti.alpha, dtype=np.uint8)
        self.app.hsti.mask_w_alpha = np.zeros_like(self.app.hsti.mask_w_alpha, dtype=np.uint8)
        self.app.hsti.bool_map = np.zeros_like(self.app.hsti.bool_map)
        self.app.viewer.specs = [{'spectrum': [], 'color': (255, 0, 0),
        'rectangle': patch.Rectangle((0,0), 1, 1, facecolor = (1, 0, 0), \
        linewidth = 1, edgecolor = 'k')}]
        self.app.viewer.display_mask()
        self.app.viewer.plot_spec()
        self.app.viewer.draw_rects()
        return

    #Resets everything in viewer
    def reset_all(self):
        self.band_slider.configure(to = self.app.hsti.cube.shape[2])
        self.band_slider.set(self.app.hsti.cube.shape[2]//3)
        self.alpha_slider.set(128)
        self.radius_slider.set(5)
        self.C_clim.set(False)
        self.C_x_axis.set(False)
        self.app.hsti.calibrated_x_axis = False
        self.debend_checkbox.configure(state=tk.NORMAL)
        self.x_axis_checkbox.configure(state=tk.NORMAL)
        self.app.viewer.current_band = self.app.hsti.cube.shape[2]//3 
        self.app.viewer.reset_viewer()
        self.clear_map()
        self.lb_preprocessing.delete(0,"end")
        self.app.viewer.im1.set_extent([0, self.app.hsti.cube.shape[1], self.app.hsti.cube.shape[0], 0])
        self.app.viewer.im2.set_extent([0, self.app.hsti.cube.shape[1], self.app.hsti.cube.shape[0], 0])
        self.app.viewer.display_mask()
        self.app.viewer.ax2.set_title('Mean spectra based on selection', pad = 10)
        self.app.viewer.ax2.set(xlabel=self.app.hsti.x_axis_label, ylabel='Intensity [a.u]')
        self.app.viewer.ax2.grid(True)
        self.app.viewer.im1.set_clim(vmin = np.nanmin(self.app.hsti.cube[:,:,self.app.viewer.current_band]),\
        vmax = np.nanmax(self.app.hsti.cube[:,:,self.app.viewer.current_band]))
        self.app.viewer.display_band()
        self.app.hsti.spatial_median_size = []
        self.app.hsti.savgol_w_length = []
        self.app.hsti.savgol_p_order = []
        self.app.hsti.savgol_deriv = []
        self.app.hsti.x_axis_label = 'Band number [#]'
        self.app.hsti.camera_ID = None
        self.app.hsti.ref_spec = None
        self.app.hsti.ref_spec_from_selection = None
        self.app.hsti.FPI_obj = None
        self.app.hsti.wl_cube = None
        self.app.hsti.ms_cube = None
        self.app.viewer.fig_TkAgg.draw()


    # color picker
    def choose_color(self):
        color_code = colorchooser.askcolor(title ="Choose color")
        color_lst = []
        for spec in self.app.viewer.specs:
            color_lst.append(spec['color'])

        if color_code != (None, None):
            zero_spec_length = next((idx for (idx, d) in enumerate(self.app.viewer.specs) if len(d['spectrum']) == 0), None)
            if zero_spec_length is not None:
                self.app.viewer.specs.pop(zero_spec_length)
            if color_code[0] not in color_lst:
                clr = tuple(rgb/255 for rgb in color_code[0])
                self.app.viewer.specs.insert(0, {'spectrum': [], 'color': color_code[0],
                'rectangle': patch.Rectangle((0,0), 1, 1, facecolor = clr, \
                linewidth = 1, edgecolor = 'k')})
            else: #Remove existing color from list and put it on top of list
                clr_idx = next((idx for (idx, d) in enumerate(self.app.viewer.specs) if d['color'] == color_code[0]), None)
                self.app.viewer.specs.insert(0, self.app.viewer.specs.pop(clr_idx))
            self.app.viewer.draw_rects()

    #Saves current band as an 8-bit grayscale image
    def save_current_band(self):
        if self.C_clim.get(): #fixed color scale
            temp = self.clim_slider.getValues()
            I8 = (((self.app.hsti.cube[:,:,self.band_slider.get() - 1] - temp[0]) / (temp[1] - temp[0])) * 255.9).astype(np.uint8)
        else: #dynamic color scale
            I8 = (((self.app.hsti.cube[:,:,self.band_slider.get() - 1] - np.nanmin(self.app.hsti.cube[self.band_slider.get() - 1]))\
             / (np.nanmax(self.app.hsti.cube[self.band_slider.get() - 1]) - np.nanmin(self.app.hsti.cube[self.band_slider.get() - 1]))) * 255.9).astype(np.uint8)
        img = Image.fromarray(I8)
        file_name = filedialog.asksaveasfilename(parent = self.parent, initialdir = self.app.hsti.path, title = "Save current band as .tif")
        if (file_name != ()) and (file_name != '\n') and (file_name != ''):
            if '.tif' in file_name:
                img.save(file_name)
            else:
                img.save(file_name+'.tif')

    #saves a .gif scrolling through the data cube
    def save_animation(self):
        file_name = filedialog.asksaveasfilename(parent = self.parent, initialdir = self.app.hsti.path, title = "Save animation as .gif")
        if (file_name != ()) and (file_name != '\n') and (file_name != ''):
            if ('.gif' in file_name) == 0:
                file_name = file_name + '.gif'
        else:
             return
        bm.clear_terminal()
        print('Saving animation...')
        colormap = hsti.import_cm()
        fig = Figure(figsize=(0.4*16*self.app.viewer.min_dim//900, 0.75*self.app.viewer.min_dim//100), dpi = self.app.viewer.DPI)
        gs = gridspec.GridSpec(1, 1) #set size ratio of the subfigures
        ax1 = fig.add_subplot(gs[:,0:3])

        im1 = ax1.imshow(self.app.hsti.cube[:,:,self.app.viewer.current_band], interpolation = 'none', cmap = colormap)
        divider = make_axes_locatable(ax1)
        cax = divider.append_axes('right', size='5%', pad=0.2)
        cbar = fig.colorbar(im1, cax=cax, orientation='vertical')

        def animate(frame):
            #update plot
            if self.C_x_axis.get() == 0:
                ax1.set_title('Band number: ' + str(frame + 1))
            else:
                ax1.set_title('Mirror separation: ' + str(round(self.app.hsti.x_axis[frame],2)) + ' [µm]')
            im1.set_data(self.app.hsti.cube[:,:,frame])
            if self.C_clim.get():
                temp = self.clim_slider.getValues()
                im1.set_clim(vmin = temp[0], vmax = temp[1])
            else:
                im1.set_clim(np.nanmin(self.app.hsti.cube), np.nanmax(self.app.hsti.cube[frame]))
            return ax1
        Writer = writers['ffmpeg']
        writer = Writer(fps=10, metadata={'artist': 'Me'}, bitrate = 1000)
        anim = FuncAnimation(fig, animate, frames=self.app.hsti.cube.shape[2], interval=100)
        anim.save(file_name, writer)

        bm.clear_terminal()
        print('Animation saved')

    #Saves .txt or .csv file containing the spectra currently plotted in viewer
    def save_specs(self):
        if len(self.app.viewer.specs) > 0:
            file_name = filedialog.asksaveasfilename(parent = self.parent, initialdir = self.app.hsti.path, title = "Save spectra")
            if (file_name != ()) and (file_name != '\n') and (file_name != ''):
                bm.clear_terminal()
                print('Saving spectra...')
                specs = np.zeros([len(self.app.viewer.specs[0]['spectrum']), len(self.app.viewer.specs)+1])
                specs[:,0] = self.app.hsti.x_axis
                for idx, spec in enumerate(self.app.viewer.specs):
                    specs[:,idx+1] = spec['spectrum']

                if any(x in file_name for x in ['.txt', '.csv']) == 0:
                    file_name = file_name + '.txt'
                np.savetxt(file_name, specs, delimiter = ',')
            bm.clear_terminal()
            print('Spectra saved')
        else:
            return


    #Saves the entire figure as .png
    def save_figure(self):
        file_name = filedialog.asksaveasfilename(parent = self.parent, initialdir = self.app.hsti.path, title = "Save figure")
        if (file_name != ()) and (file_name != '\n') and (file_name != ''):
            bm.clear_terminal()
            print('Saving figure...')
            if '.' in file_name:
                self.app.viewer.fig.savefig(file_name)
            else:
                self.app.viewer.fig.savefig(file_name+'.png')
            bm.clear_terminal()
            print('Figure saved')

    def savgol(self, cube, list_box):
        # self.show_x_axis_dialog()

        if self.app.hsti.savgol_w_length == []:
            w_length = tk.simpledialog.askinteger(title = 'Input box', prompt = 'Input window length, must be odd, positive integer')
            if (w_length != None) and (w_length % 2 != 0):
                p_order = tk.simpledialog.askinteger(title = 'Input box', prompt = 'Input polynomial order - must be integer >= 1')
            else:
                label = "Savitzky-Golay filter"
                idx = list_box.get(0, "end").index(label)
                list_box.delete(idx)
                return cube


            if (p_order != None) and (p_order >= 1):
                derivative = tk.simpledialog.askinteger(title = 'Input box', prompt = 'Input derivative order - must be integer >= 0')
            else:
                label = "Savitzky-Golay filter"
                idx = list_box.get(0, "end").index(label)
                list_box.delete(idx)
                return cube

            if (derivative != None) and (derivative >= 0):
                self.app.hsti.savgol_w_length = w_length
                self.app.hsti.savgol_p_order = p_order
                self.app.hsti.savgol_deriv = derivative
                return savgol_filter(cube, window_length = w_length, polyorder = p_order, deriv = derivative, axis= 2)
            else:
                label = "Savitzky-Golay filter"
                idx = list_box.get(0, "end").index(label)
                list_box.delete(idx)
                return cube
        else:
            return savgol_filter(cube, window_length = self.app.hsti.savgol_w_length, polyorder = self.app.hsti.savgol_p_order, deriv = self.app.hsti.savgol_deriv, axis= 2)

    def m2w(self):
        if self.app.hsti.camera_ID == None:
            dialog = Camera_Dialog(title="Dropdown dialog", parent=self.parent)
            self.app.hsti.camera_ID = dialog.camera_ID
        if self.app.hsti.calibrated_x_axis is False:
            self.C_x_axis.set(True)
            self.update_x_axis()
                    
        correction_factor = tk.simpledialog.askfloat(title = 'Input box', prompt = 'Correction factor for matrix inversion - must be positive', initialvalue=1.5e4)
        lams = np.linspace(8,16,250)*1e-6
        
        if self.app.hsti.FPI_obj == None:
            self.app.hsti.FPI_obj = hsti.FPI(self.app.hsti.x_axis*1e-6, lams, 297)
            if self.app.hsti.camera_ID == '10_10_200_191':
                self.app.hsti.FPI_obj.apply_camera_response('data_files/camera_responses/10_10_200_191/response_191camera.pkl')
            elif self.app.hsti.camera_ID == '10_10_200_22':
                self.app.hsti.FPI_obj.apply_camera_response('data_files/camera_responses/10_10_200_22/response_22camera.pkl')
        self.app.hsti.x_axis = lams*1e6
        self.app.hsti.ms_cube = self.app.hsti.cube
        self.app.hsti.cube = self.app.hsti.FPI_obj.ms2wl(hsti.flatten(self.app.hsti.cube).T, correction_factor = correction_factor).T
        self.app.hsti.cube = np.reshape(self.app.hsti.cube, [self.app.hsti.ms_cube.shape[0], self.app.hsti.ms_cube.shape[1], len(self.app.hsti.FPI_obj.lams)])
        self.app.hsti.cube = hsti.normalize_cube(self.app.hsti.cube)
        self.band_slider.configure(to = self.app.hsti.cube.shape[2])
        self.app.hsti.x_axis_label = 'Wavelength [µm]'

    def generate_ref_spec(self):
        if self.app.hsti.camera_ID == None:
            dialog = Camera_Dialog(title="Dropdown dialog", parent=self.parent)
            self.app.hsti.camera_ID = dialog.camera_ID
        if self.app.hsti.calibrated_x_axis is False:
            self.C_x_axis.set(True)
            self.update_x_axis()
        if self.app.hsti.FPI_obj == None:
            lams = np.linspace(8,16,250)*1e-6
            self.app.hsti.FPI_obj = hsti.FPI(self.app.hsti.x_axis*1e-6, lams, 297)
            if self.app.hsti.camera_ID == '10_10_200_191':
                self.app.hsti.FPI_obj.apply_camera_response('data_files/camera_responses/10_10_200_191/response_191camera.pkl')
            elif self.app.hsti.camera_ID == '10_10_200_22':
                self.app.hsti.FPI_obj.apply_camera_response('data_files/camera_responses/10_10_200_22/response_22camera.pkl')
        self.app.hsti.ref_spec = np.zeros_like(self.app.hsti.x_axis*1e-6)
        for i in range(self.app.hsti.FPI_obj.trans_matrix.shape[0]):
            self.app.hsti.ref_spec[i] += np.sum(self.app.hsti.FPI_obj.trans_matrix[i,:])
        self.app.hsti.ref_spec = self.app.hsti.ref_spec/np.max(self.app.hsti.ref_spec)
        # temp_cube = self.app.hsti.cube[:,3:-10,:]/self.app.hsti.ref_spec
        # max_diff_idx = np.where(temp_cube == np.max(temp_cube))
        # self.app.hsti.ref_spec = self.app.hsti.ref_spec*(self.app.hsti.cube[max_diff_idx[0][0],3+max_diff_idx[1][0],max_diff_idx[2][0]]/self.app.hsti.ref_spec[max_diff_idx[2][0]])


    def subtract_ref_spec(self):
        self.generate_ref_spec()
        temp_cube = self.app.hsti.cube / self.app.hsti.ref_spec
        scaling = np.max(temp_cube, axis = 2)
        self.app.hsti.cube = self.app.hsti.cube - self.app.hsti.ref_spec*scaling[:,:,np.newaxis]

    def divide_by_ref_spec(self):    
        self.generate_ref_spec()
        self.app.hsti.cube = hsti.normalize(self.app.hsti.cube, 's')
        temp_cube = self.app.hsti.cube / self.app.hsti.ref_spec
        scaling = np.max(temp_cube, axis = 2)
        scaling[scaling < 1e-6] = np.median(scaling)
        self.app.hsti.cube = self.app.hsti.cube/(self.app.hsti.ref_spec*scaling[:,:,np.newaxis])

    def reference_spec_from_selection(self): #This function uses the latest selection as the reference. All pixels in the cube are then subtracted from this spectrum
        if (len(self.app.viewer.specs) > 0) & (self.app.hsti.ref_spec_from_selection == None):
            self.app.hsti.ref_spec_from_selection = self.app.viewer.specs[0]['spectrum']
            self.app.hsti.cube = self.app.hsti.ref_spec_from_selection - self.app.hsti.cube

    def median_filter_cube(self, data_cube, list_box):
        if self.app.hsti.spatial_median_size == []:
            kernel_size = tk.simpledialog.askinteger(title = 'Input box', prompt = 'Kernel size, must be odd integer')
            if (kernel_size != None) and ((kernel_size%2) != 0):
                self.app.hsti.spatial_median_size = kernel_size
                band_lst = []
                for i in range(data_cube.shape[2]):
                    band_lst.append(data_cube[:,:,i])
                kernel_size_lst = np.ones(len(band_lst), dtype = int)*kernel_size
                with cf.ThreadPoolExecutor() as executor:
                    results = executor.map(median_filter, band_lst, kernel_size_lst)
                filtered_cube = np.zeros_like(data_cube)
                for i, result in enumerate(results):
                    filtered_cube[:,:,i] = result
            else:
                label = "Spatial median filter"
                idx = list_box.get(0, "end").index(label)
                list_box.delete(idx)
                return data_cube
        else:
            band_lst = []
            for i in range(data_cube.shape[2]):
                band_lst.append(data_cube[:,:,i])
            kernel_size_lst = np.ones(len(band_lst), dtype = int)*self.app.hsti.spatial_median_size
            with cf.ThreadPoolExecutor() as executor:
                results = executor.map(median_filter, band_lst, kernel_size_lst)
            filtered_cube = np.zeros_like(data_cube)
            for i, result in enumerate(results):
                filtered_cube[:,:,i] = result
        return filtered_cube


    def invert_selection(self):
        self.app.hsti.mask_w_alpha = np.zeros([self.app.hsti.cube.shape[0], self.app.hsti.cube.shape[1], 4], dtype=np.uint8)
        self.app.hsti.mask_no_alpha = np.ones([self.app.hsti.cube.shape[0], self.app.hsti.cube.shape[1], 3], dtype=np.uint8)
        self.app.hsti.alpha = np.zeros([self.app.hsti.cube.shape[0], self.app.hsti.cube.shape[1]], dtype=np.uint8)
        self.app.hsti.bool_map = np.invert(self.app.hsti.bool_map.astype(bool))

        self.app.hsti.alpha[self.app.hsti.bool_map] = self.alpha_slider.get()
        self.app.hsti.mask_no_alpha[self.app.hsti.bool_map] = self.app.viewer.specs[0]['color']
        self.app.hsti.mask_w_alpha[:,:,0:3] = self.app.hsti.mask_no_alpha
        self.app.hsti.mask_w_alpha[:,:,-1] = self.app.hsti.alpha
        self.app.hsti.bool_map = self.app.hsti.bool_map.astype(float)
        self.app.viewer.display_mask()
        self.app.viewer.calc_spec()
        self.app.viewer.plot_spec()
        self.app.viewer.draw_rects()

    def remove_data(self): 
        self.app.hsti.bool_map = self.app.hsti.bool_map.astype(bool)
        self.app.hsti.cube[self.app.hsti.bool_map,:] = np.nan
        self.app.hsti.bool_map = self.app.hsti.bool_map.astype(float)
        self.app.viewer.display_band()
        self.clear_map()

    def flip_up_down(self): 
        self.app.hsti.cube = np.ascontiguousarray(np.flipud(self.app.hsti.cube))
        self.app.hsti.bool_map = np.ascontiguousarray(np.flipud(self.app.hsti.bool_map))
        self.app.hsti.mask_w_alpha = np.ascontiguousarray(np.flipud(self.app.hsti.mask_w_alpha))
        self.app.hsti.mask_no_alpha = np.ascontiguousarray(np.flipud(self.app.hsti.mask_no_alpha))
        self.app.hsti.alpha = np.ascontiguousarray(np.flipud(self.app.hsti.alpha))
        self.app.viewer.display_band()
        self.app.viewer.display_mask()

    def flip_left_right(self):     
        self.app.hsti.cube = np.ascontiguousarray(np.fliplr(self.app.hsti.cube))
        self.app.hsti.bool_map = np.ascontiguousarray(np.fliplr(self.app.hsti.bool_map))
        self.app.hsti.mask_w_alpha = np.ascontiguousarray(np.fliplr(self.app.hsti.mask_w_alpha))
        self.app.hsti.mask_no_alpha = np.ascontiguousarray(np.fliplr(self.app.hsti.mask_no_alpha))
        self.app.hsti.alpha = np.ascontiguousarray(np.fliplr(self.app.hsti.alpha))
        self.app.viewer.display_band()
        self.app.viewer.display_mask()


#####################
### CUSTOM DIALOG ###
#####################

    def show_x_axis_dialog(self, parent, app):
        MyDialog(title="Select x-asis", parent=parent, app=app)

class MyDialog(tk.simpledialog.Dialog): #https://code-maven.com/slides/python/tk-customized-simple-dialog
    def __init__(self, parent, title, app):
        self.my_username = None
        self.my_password = None
        self.app = app
        super().__init__(parent, title)

    def body(self, frame):
        # print(type(frame)) # tkinter.Frame
        self.my_text = tk.Label(frame, width=50, text="Choose option for calibrating x-axis")
        self.my_text.pack()
        return frame

    def relative_mirror_sep(self):
        offset = tk.simpledialog.askfloat(title = 'Mirror separation offset', prompt = 'Please input offset of mirror separation axis [µm]', initialvalue=0.0)
        if offset != None:
            self.app.hsti.x_axis = bm.relative_mirror_separation(self.app.hsti.path)*1e6 + offset
            if offset == 0.0:
                self.app.hsti.x_axis_label = 'Relative mirror separation [µm]'
            else:
                self.app.hsti.x_axis_label = 'Mirror separation [µm]'
            self.app.hsti.calibrated_x_axis = True
            self.app.viewer.display_band()
            self.app.viewer.plot_spec()
            self.destroy()

    def polynomial_mirror_sep(self):
        file_path = filedialog.askopenfilename(parent = self.parent,\
            initialdir = self.app.hsti.path, title = "Choose x-axis calibration file (.npy)")
        if '.npy' not in file_path:
            mb.showerror('Error', 'Please choose a valid file format')
        else: 
            poly = np.poly1d(np.load(file_path))
            self.app.hsti.x_axis = poly(np.linspace(0, self.app.hsti.cube.shape[2], self.app.hsti.cube.shape[2]))
            self.app.hsti.x_axis_label = 'Mirror separation [µm]'
            self.app.hsti.calibrated_x_axis = True
            self.app.viewer.display_band()
            self.app.viewer.plot_spec()
            self.destroy()

    def vector_mirror_sep(self):
        file_path = filedialog.askopenfilename(parent = self.parent,\
            initialdir = self.app.hsti.path, title = "Choose x-axis calibration file (.npy, .txt, or .csv)")
        if '.npy' not in file_path and '.txt' not in file_path and '.csv' not in file_path:
            mb.showerror('Error', 'Please choose a valid file format')
        else:
            self.app.hsti.x_axis_label = tk.simpledialog.askstring(title = 'x-axis name', prompt = 'Please enter x-axis name', initialvalue='Mirror separation [µm]')
            if '.npy' in file_path:
                self.app.hsti.x_axis = np.load(file_path)
            else:
                self.app.hsti.x_axis = np.loadtxt(file_path)
            self.app.hsti.calibrated_x_axis = True
            self.app.viewer.display_band()
            self.app.viewer.plot_spec()
            self.destroy()

    def cancel_pressed(self):
        # print("cancel")
        self.destroy()

    def buttonbox(self):
        self.relative_sep_btn = tk.Button(self, text='Relative mirror separation', width=20, command=self.relative_mirror_sep)
        self.relative_sep_btn.pack(side="left")
        self.polynomial_btn = tk.Button(self, text='Numpy polynomial (.npy)', width=20, command=self.polynomial_mirror_sep)
        self.polynomial_btn.pack(side="left")
        self.vector_btn = tk.Button(self, text='Vector (.npy, .txt, or .csv)', width=20, command=self.vector_mirror_sep)
        self.vector_btn.pack(side="left")
        cancel_button = tk.Button(self, text='Cancel', width=5, command=self.cancel_pressed)
        cancel_button.pack(side="left")
        self.bind("<Escape>", lambda event: self.cancel_pressed())


# class MyDialog(tk.simpledialog.Dialog): #https://code-maven.com/slides/python/tk-customized-simple-dialog
#     def __init__(self, parent, title):
#         self.my_username = None
#         self.my_password = None
#         super().__init__(parent, title)

#     def body(self, frame):
#         # print(type(frame)) # tkinter.Frame
#         self.my_username_label = tk.Label(frame, width=25, text="Username")
#         self.my_username_label.pack()
#         self.my_username_box = tk.Entry(frame, width=25)
#         self.my_username_box.pack()

#         self.my_password_label = tk.Label(frame, width=25, text="Password")
#         self.my_password_label.pack()
#         self.my_password_box = tk.Entry(frame, width=25)
#         self.my_password_box.pack()
#         self.my_password_box['show'] = '*'

#         return frame

#     def ok_pressed(self):
#         # print("ok")
#         self.my_username = self.my_username_box.get()
#         self.my_password = self.my_password_box.get()
#         self.destroy()

#     def cancel_pressed(self):
#         # print("cancel")
#         self.destroy()

#     def buttonbox(self):
#         self.ok_button = tk.Button(self, text='OK', width=5, command=self.ok_pressed)
#         self.ok_button.pack(side="left")
#         cancel_button = tk.Button(self, text='Cancel', width=5, command=self.cancel_pressed)
#         cancel_button.pack(side="right")
#         self.bind("<Return>", lambda event: self.ok_pressed())
#         self.bind("<Escape>", lambda event: self.cancel_pressed())
