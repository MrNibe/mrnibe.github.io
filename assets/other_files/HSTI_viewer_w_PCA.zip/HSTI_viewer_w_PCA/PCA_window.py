import numpy as np
import tkinter as tk
import matplotlib
matplotlib.use("TkAgg")
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
from matplotlib.figure import Figure
from matplotlib import gridspec
from mpl_toolkits.axes_grid1 import make_axes_locatable
import matplotlib.pyplot as plt
import cv2 as cv
from HSTI_Class import HSTI
import Basic_Math as bm
from fast_histogram import histogram2d
import matplotlib.colors as colors
import time
from Loadings_window import loadings_window
import HSTI as hsti
from sklearn.decomposition import PCA


class pca_window(tk.Frame):


    ########## Setup window and initiate member variables ##########
    def __init__(self, the_window, the_app):
        self.x_coors_pca, self.y_coors_pca, self.x_coors_dsp, self.y_coors_dsp = [], [], [], []
        self.app = the_app
        self.dsp_size = int(30*np.log(np.sqrt(np.count_nonzero(~np.isnan(self.app.hsti.cube[:,:,0])))))
        self.mask_no_alpha_pca = np.ones([self.app.hsti.cube.shape[0], self.app.hsti.cube.shape[1], 3], dtype=np.uint8)
        self.alpha_pca = np.zeros([self.app.hsti.cube.shape[0], self.app.hsti.cube.shape[1]], dtype=np.uint8)
        self.mask_w_alpha_pca = np.zeros([self.app.hsti.cube.shape[0], self.app.hsti.cube.shape[1], 4], dtype=np.uint8)
        # self.bool_map_pca = np.zeros([self.app.hsti.cube.shape[0], self.app.hsti.cube.shape[1]])
        self.mask_no_alpha_dsp = np.ones([self.dsp_size, self.dsp_size, 3], dtype=np.uint8)
        self.alpha_dsp = np.zeros([self.dsp_size, self.dsp_size], dtype=np.uint8)
        self.mask_w_alpha_dsp = np.zeros([self.dsp_size, self.dsp_size, 4], dtype=np.uint8)
        # self.bool_map_dsp = np.zeros([self.dsp_size, self.dsp_size])
        self.colors = []
        super().__init__(width = the_window.winfo_screenwidth(), height = 3*the_window.winfo_screenheight()//4)
        self.bck = 'white'
        self.canvas = tk.Canvas(self, width = the_window.winfo_screenwidth(), height = 3*the_window.winfo_screenheight()//4, background = self.bck)
        self['bg'] = self.bck
        self.parent = the_window
        self.width = self.app.window_width//2
        self.height = self.app.window_height//8
        self.window = tk.Toplevel(self.parent, bg = self.bck)
        self.window.title('PCA window')
        self.DPI = 100
        self.min_dim = min([self.app.window_width, self.app.window_height])
        self.fig = Figure(figsize=(0.8*16*self.min_dim/900, 0.70*self.min_dim/100), dpi = self.DPI)
        gs = gridspec.GridSpec(2, 2) #set size ratio of the subfigures
        self.ax1 = self.fig.add_subplot(gs[:,0])
        self.ax2 = self.fig.add_subplot(gs[:,1])
        self.cbar2 = None
        self.window.columnconfigure(0, weight = 1)
        self.window.columnconfigure(1, weight = 2)
        self.window.columnconfigure(2, weight = 2)
        self.window.columnconfigure(3, weight = 2)
        self.window.columnconfigure(4, weight = 2)
        self.window.columnconfigure(5, weight = 1)

        self.fig_TkAgg = FigureCanvasTkAgg(self.fig, master = self.window)
        self.fig_TkAgg.draw()
        self.fig_TkAgg.get_tk_widget().grid(row=0,column=0, columnspan = 6)
        self.fig.canvas.mpl_connect('button_press_event', self.onclick)
        self.fig.canvas.mpl_connect('button_release_event', self.onrelease)
        self.fig.canvas.mpl_connect('motion_notify_event', self.onmove)

        ########## Calculate and plot PCA of data_cube ##########
        self.calculate_pca()
        colormap = hsti.import_cm()
        self.im1 = self.ax1.imshow(self.scores[:,0].reshape([self.app.hsti.cube.shape[0],self.app.hsti.cube.shape[1]]), interpolation = 'none', cmap = colormap)
        self.im1_overlay = self.ax1.imshow(self.mask_w_alpha_pca, interpolation = 'none', alpha = 1)
        self.ax1.set_title(f'Scores, PC {1}, {round(self.pct_expl_var[0],2)}%', pad = 10)
        divider = make_axes_locatable(self.ax1)
        cax = divider.append_axes('right', size='2%', pad=0.2)
        cbar = self.fig.colorbar(self.im1, cax=cax, orientation='vertical')
        self.idx1 = 0
        self.idx2 = 1
        self.im2 = self.density_scatter(self.scores[:,self.idx1], self.scores[:,self.idx2])
        self.ax2.set_xlabel(f'Scores, PC {self.idx1+1}, {round(self.pct_expl_var[self.idx1],2)}%')
        self.ax2.set_ylabel(f'Scores, PC {self.idx2+1}, {round(self.pct_expl_var[self.idx2],2)}%')
        self.fig.tight_layout(pad=3)


        ########## LIST BOXES + TITLES ##########
        self.lb_score_img_title = tk.Label(self.window, text = "Score image", bg = self.bck)
        self.lb_score_img_title.grid(row = 1, column = 1, columnspan = 2)
        self.lb_score_img = tk.Listbox(self.window, height = 5, exportselection = False)
        self.lb_score_img.grid(row = 2, column = 1, columnspan = 2, sticky = 'nsew')
        self.lb_score_img.bind('<<ListboxSelect>>', self.update_scores)

        self.lb_score_ax1_title = tk.Label(self.window, text = "Component, x-axis", bg = self.bck)
        self.lb_score_ax1_title.grid(row = 1, column = 3)
        self.lb_score_ax1 = tk.Listbox(self.window, height = 5, exportselection = False)
        self.lb_score_ax1.grid(row = 2, column = 3, sticky = 'nsew')
        self.lb_score_ax1.bind('<<ListboxSelect>>', self.update_dsp_x)

        self.lb_score_ax2_title = tk.Label(self.window, text = "Component, y-axis", bg = self.bck)
        self.lb_score_ax2_title.grid(row = 1, column = 4)
        self.lb_score_ax2 = tk.Listbox(self.window, height = 5, exportselection = False)
        self.lb_score_ax2.grid(row = 2, column = 4, sticky = 'nsew')
        self.lb_score_ax2.bind('<<ListboxSelect>>', self.update_dsp_y)

        options = []
        for i in range(self.scores.shape[1]):
            options.append(f'Scores, PC {i+1}, {round(self.pct_expl_var[i],2)}%')
            self.lb_score_img.insert("end",options[-1])
            self.lb_score_ax1.insert("end",options[-1])
            self.lb_score_ax2.insert("end",options[-1])

        # button for loadings plot
        self.loadings_btn  = tk.Button(self.window, text = 'Plot loadings', bg = self.bck, command = lambda: loadings_window(self, self.app))
        self.loadings_btn.grid(row = 3, column = 3)

        self.window.protocol("WM_DELETE_WINDOW", self.quit_me)


        ########## TOOLBAR ##########
        # toolbarFrame = tk.Frame(master=self.window)
        # toolbarFrame.grid(row=4,column=0, columnspan = 6)
        # toolbar = NavigationToolbar2Tk(self.fig_TkAgg, toolbarFrame)

    ########## Function for calculating PCA ##########
    def calculate_pca(self):
        print('Calculating PCA')
        self.flat_cube = np.reshape(self.app.hsti.cube, [self.app.hsti.cube.shape[0]*self.app.hsti.cube.shape[1], self.app.hsti.cube.shape[2]])
        if self.app.hsti.cube.shape[2] < 1000:
            nan_map = np.isnan(self.flat_cube) #form boolean array with true values everywhere a np.nan is encountered
            if nan_map.any(): #If array_2D contains np.nan, do this
                nan_row_idx = np.unique(np.argwhere(nan_map)[:,0]) #Find every row containing nan
                nan_map[nan_row_idx,:] = True #Expand the map to mark entire row
                cov = np.cov((self.flat_cube[~nan_map].reshape(self.flat_cube.shape[0]-len(nan_row_idx), -1)).T) #exclude marked rows from cov calculation
                del nan_row_idx
            else:
                cov = np.cov(self.flat_cube.T)
            del nan_map
            self.expl_var, self.loadings = np.linalg.eig(cov) #expl_var are the singular values, while P are the loadings of flat_cube
            self.expl_var = np.real(self.expl_var)
            self.loadings = np.real(self.loadings)
            index = self.expl_var.argsort()[::-1]
            self.expl_var = self.expl_var[index]
            self.pct_expl_var = 100*self.expl_var/np.sum(self.expl_var)
            self.loadings = self.loadings[:,index]
            #calculate the percentage of explained variance for each of the eigen values - this corresponds to the contribution of each PC
            self.expl_var_ratio = self.expl_var/np.sum(self.expl_var)
            self.scores = self.flat_cube @ self.loadings
        else:
            print('Using sklearn PCA')
            sklearn_pca = PCA(n_components = 100, copy=False, whiten=False, svd_solver='randomized', iterated_power=1)
            self.scores = sklearn_pca.fit(self.flat_cube).transform(self.flat_cube)    
            self.loadings = sklearn_pca.components_.T
            self.expl_var = sklearn_pca.explained_variance_
            self.expl_var_ratio = sklearn_pca.explained_variance_ratio_
            self.pct_expl_var = 100*self.expl_var_ratio


    ########## Update score image plot ##########
    def update_scores(self, event):
        idx = self.lb_score_img.curselection()[0]
        self.im1.set_data(self.scores[:,idx].reshape([self.app.hsti.cube.shape[0],self.app.hsti.cube.shape[1]]))
        self.im1.set_clim(vmin = np.nanmin(self.scores[:,idx]), vmax = np.nanmax(self.scores[:,idx]))
        self.ax1.set_title(f'Scores, PC {idx+1}, {round(self.pct_expl_var[idx],2)}%', pad = 10)
        self.fig_TkAgg.draw()
        return

    ########## Update density scatter plot, when new x-axis is selected ##########
    def update_dsp_x(self, event):
        self.ax2.cla()
        self.idx1 = self.lb_score_ax1.curselection()[0]
        # self.cbar2.remove()
        self.density_scatter(self.scores[:,self.idx1], self.scores[:,self.idx2])
        self.ax2.set_xlabel(f'Scores, PC {self.idx1+1}, {round(self.pct_expl_var[self.idx1],2)}%')
        self.ax2.set_ylabel(f'Scores, PC {self.idx2+1}, {round(self.pct_expl_var[self.idx2],2)}%')
        self.mask_no_alpha_dsp = np.ones([self.dsp_size, self.dsp_size, 3], dtype=np.uint8)
        self.alpha_dsp = np.zeros([self.dsp_size, self.dsp_size], dtype=np.uint8)
        self.mask_w_alpha_dsp = np.zeros([self.dsp_size, self.dsp_size, 4], dtype=np.uint8)
        self.scoreimg2dsp()
        self.display_mask_dsp()
        return

    ########## Update density scatter plot, when new y-axis is selected ##########
    def update_dsp_y(self, event):
        self.ax2.cla()
        self.idx2 = self.lb_score_ax2.curselection()[0]
        # self.cbar2.remove()
        self.density_scatter(self.scores[:,self.idx1], self.scores[:,self.idx2])
        self.ax2.set_xlabel(f'Scores, PC {self.idx1+1}, {round(self.pct_expl_var[self.idx1],2)}%')
        self.ax2.set_ylabel(f'Scores, PC {self.idx2+1}, {round(self.pct_expl_var[self.idx2],2)}%')
        self.mask_no_alpha_dsp = np.ones([self.dsp_size, self.dsp_size, 3], dtype=np.uint8)
        self.alpha_dsp = np.zeros([self.dsp_size, self.dsp_size], dtype=np.uint8)
        self.mask_w_alpha_dsp = np.zeros([self.dsp_size, self.dsp_size, 4], dtype=np.uint8)
        self.scoreimg2dsp()
        self.display_mask_dsp()
        return

    ########## Functions which registers mouse input ##########
    def onclick(self, event):
        if event.inaxes is not None:
            self.ax = event.inaxes
            if event.button == 1 or event.button == 3: # 1 =  Left click, 3 = Right click
                if self.ax == self.ax1:  #Only valid inside left pane
                    self.x_coors_pca, self.y_coors_pca = [], []
                    self.x_coors_pca.append(int(event.xdata))
                    self.y_coors_pca.append(int(event.ydata))
                if self.ax == self.ax2:  #Only valid inside right pane
                    self.x_coors_dsp, self.y_coors_dsp = [], []
                    self.x_coors_dsp.append(self.dsp2mask_x(event.xdata))
                    self.y_coors_dsp.append(self.dsp2mask_y(event.ydata))

    ########## Functions which registers mouse input ##########
    def onrelease(self, event):
        if event.inaxes is not None:
            self.ax = event.inaxes
            if event.button == 1: # Left click
                if self.ax == self.ax1:
                    self.x_coors_pca.append(int(event.xdata))
                    self.y_coors_pca.append(int(event.ydata))
                    self.paint_pca()
                    self.scoreimg2dsp()
                    self.display_mask_pca()
                    self.display_mask_dsp()
                if self.ax == self.ax2:
                    self.x_coors_dsp.append(self.dsp2mask_x(event.xdata))
                    self.y_coors_dsp.append(self.dsp2mask_y(event.ydata))
                    self.paint_dsp()
                    self.dsp2scoreimg()
                    self.display_mask_dsp()
                    self.display_mask_pca()
            if event.button == 3: # Right click
                if self.ax == self.ax1:
                    self.x_coors_pca.append(int(event.xdata))
                    self.y_coors_pca.append(int(event.ydata))
                    self.erase_pca()
                    self.scoreimg2dsp()
                    self.display_mask_pca()
                    self.display_mask_dsp()
                if self.ax == self.ax2:
                    self.x_coors_dsp.append(self.dsp2mask_x(event.xdata))
                    self.y_coors_dsp.append(self.dsp2mask_y(event.ydata))
                    self.erase_dsp()
                    self.dsp2scoreimg()
                    self.display_mask_dsp()
                    self.display_mask_pca()


    ########## Functions which registers mouse input ##########
    def onmove(self, event):
        if event.inaxes is not None:
            self.ax = event.inaxes
            if event.button == 1: # Left click
                if self.ax == self.ax1:
                    self.x_coors_pca.append(int(event.xdata))
                    self.y_coors_pca.append(int(event.ydata))
                    self.paint_pca()
                    self.display_mask_pca()
                if self.ax == self.ax2:
                    self.x_coors_dsp.append(self.dsp2mask_x(event.xdata))
                    self.y_coors_dsp.append(self.dsp2mask_y(event.ydata))
                    self.paint_dsp()
                    self.display_mask_dsp()
            if event.button == 3: # Right click
                if self.ax == self.ax1:
                    self.x_coors_pca.append(int(event.xdata))
                    self.y_coors_pca.append(int(event.ydata))
                    self.erase_pca()
                    self.display_mask_pca()
                if self.ax == self.ax2:
                    self.x_coors_dsp.append(self.dsp2mask_x(event.xdata))
                    self.y_coors_dsp.append(self.dsp2mask_y(event.ydata))
                    self.erase_dsp()
                    self.display_mask_dsp()

    ########## Paint on score image based on registered coordinates ##########
    def paint_pca(self):
        if len(self.x_coors_pca) > 1:
            cv.line(self.mask_no_alpha_pca, (self.x_coors_pca[-2], self.y_coors_pca[-2]), (self.x_coors_pca[-1], self.y_coors_pca[-1]), self.app.viewer.specs[0]['color'], self.app.button_layout.radius_slider.get())
            self.mask_w_alpha_pca[:,:,0:3] = self.mask_no_alpha_pca
            self.alpha_pca[np.sum(self.mask_no_alpha_pca, axis = 2) != 3] = self.app.button_layout.alpha_slider.get() #find all elements which do not have rgb value = (1,1,1)
            self.mask_w_alpha_pca[:,:,3] = self.alpha_pca
        return

    ########## Paint on DSP based on registered coordinates ##########
    def paint_dsp(self):
        if len(self.x_coors_dsp) > 1:
            cv.line(self.mask_no_alpha_dsp, (self.x_coors_dsp[-2], self.y_coors_dsp[-2]), (self.x_coors_dsp[-1], self.y_coors_dsp[-1]), self.app.viewer.specs[0]['color'], self.app.button_layout.radius_slider.get())
            self.mask_w_alpha_dsp[:,:,0:3] = self.mask_no_alpha_dsp
            self.alpha_dsp[np.sum(self.mask_no_alpha_dsp, axis = 2) != 3] = self.app.button_layout.alpha_slider.get()
            self.mask_w_alpha_dsp[:,:,3] = self.alpha_dsp
            # self.ax2.imshow(self.alpha_dsp)
            # self.fig_TkAgg.draw()
        return

    ########## Erases mask on score image based on registered coordinates ##########
    def erase_pca(self):
        if len(self.x_coors_pca) > 1:
            cv.line(self.alpha_pca, (self.x_coors_pca[-2], self.y_coors_pca[-2]), (self.x_coors_pca[-1], self.y_coors_pca[-1]), 0, self.app.button_layout.radius_slider.get())
            self.mask_w_alpha_pca[self.alpha_pca == 0] = 1
            self.mask_w_alpha_pca[:,:,3] = self.alpha_pca
            self.mask_no_alpha_pca = np.copy(self.mask_w_alpha_pca[:,:,:3])
            self.mask_no_alpha_dsp = np.ones([self.dsp_size, self.dsp_size, 3], dtype=np.uint8)
            self.alpha_dsp = np.zeros([self.dsp_size, self.dsp_size], dtype=np.uint8)
            self.mask_w_alpha_dsp = np.zeros([self.dsp_size, self.dsp_size, 4], dtype=np.uint8)

    ########## Erases mask on DSP based on registered coordinates ##########
    def erase_dsp(self):
        if len(self.x_coors_dsp) > 1:
            self.mask_no_alpha_pca = np.ones([self.app.hsti.cube.shape[0], self.app.hsti.cube.shape[1], 3], dtype=np.uint8)
            self.alpha_pca = np.zeros([self.app.hsti.cube.shape[0], self.app.hsti.cube.shape[1]], dtype=np.uint8)
            self.mask_w_alpha_pca = np.zeros([self.app.hsti.cube.shape[0], self.app.hsti.cube.shape[1], 4], dtype=np.uint8)  
            cv.line(self.alpha_dsp, (self.x_coors_dsp[-2], self.y_coors_dsp[-2]), (self.x_coors_dsp[-1], self.y_coors_dsp[-1]), 0, self.app.button_layout.radius_slider.get())
            self.mask_w_alpha_dsp[self.alpha_dsp == 0] = 1
            self.mask_w_alpha_dsp[:,:,3] = self.alpha_dsp
            self.mask_no_alpha_dsp = np.copy(self.mask_w_alpha_dsp[:,:,:3])

    ########## Display masks on score image and DSP ##########
    def display_mask_dsp(self):
        self.im2_overlay.set_data(self.mask_w_alpha_dsp)
        # self.fig_TkAgg.draw()
        self.fig.canvas.draw_idle()

    def display_mask_pca(self):
        self.im1_overlay.set_data(self.mask_w_alpha_pca)
        # self.fig_TkAgg.draw()
        self.fig.canvas.draw_idle()

    ########## Calculate and plot density scatter plot ##########
    def density_scatter(self, X, Y):
        # cmap = plt.get_cmap('viridis')
        cmap = hsti.import_cm()
        self.bnds = [[np.nanmin(X), np.nanmax(X)], [np.nanmin(Y), np.nanmax(Y)]]
        h = histogram2d(X, Y, range=self.bnds, bins=self.dsp_size)
        h = np.rot90(h)
        self.im2 = self.ax2.imshow(h, extent=[self.bnds[0][0],self.bnds[0][1],self.bnds[1][0],self.bnds[1][1]], aspect='auto',\
                   norm=colors.LogNorm(vmin=1, vmax=h.max()), cmap=cmap, interpolation = 'none')
        self.im2_overlay = self.ax2.imshow(self.mask_w_alpha_dsp,\
        extent=[self.bnds[0][0],self.bnds[0][1],self.bnds[1][0],self.bnds[1][1]], aspect='auto', alpha = 1, interpolation = 'none')
        self.ax2.set_title('Density scatter plot', pad = 10)
        self.scalar_mappable = plt.cm.ScalarMappable(norm=colors.LogNorm(vmin=1, vmax=h.max()), cmap = cmap)
        if self.cbar2 == None:
            self.cbar2 = self.fig.colorbar(self.scalar_mappable, ax = self.ax2, orientation='vertical', label='Number of points per pixel')
        else:
            self.cbar2.mappable.set_clim(vmin=1, vmax=h.max())

   
    #Functions for calculating the coordinates of the DSP mask, based on cursor
    #position. This is done by making a linear fit between the DSP axes and
    #corresponding positions in a matrix.
    def dsp2mask_x(self, x_vec):
        x_slope = (self.dsp_size-1)/(self.bnds[0][1] - self.bnds[0][0])
        x_intercept = 0 - x_slope*self.bnds[0][0]
        new_x = x_slope*x_vec + x_intercept
        return np.round(new_x).astype(int) #Result must be int, as it functions as mask index

    def dsp2mask_y(self, y_vec):
        # The slope is negative, because the new y-axis runs in opposite direction
        y_slope = -(self.dsp_size-1)/(self.bnds[1][1] - self.bnds[1][0])
        y_intercept = (self.dsp_size-1) - y_slope*self.bnds[1][0]
        new_y = y_slope*y_vec + y_intercept
        return np.round(new_y).astype(int)

    ########## Converting back from matrix indices to dsp coordinates ##########
    def mask2dsp_x(self, x_vec):
        x_slope = (self.bnds[0][1] - self.bnds[0][0])/(self.dsp_size-1)
        x_intercept = self.bnds[0][0]
        new_x = x_slope*x_vec + x_intercept
        return new_x

    def mask2dsp_y(self, y_vec):
        y_slope = -(self.bnds[1][1] - self.bnds[1][0])/(self.dsp_size-1)
        y_intercept = self.bnds[1][1]
        new_y = y_slope*y_vec + y_intercept
        return new_y

    ########## Converts pixel positions in the score image to a mask in the DSP ##########
    def scoreimg2dsp(self):
        #Get all unique colors from the mask    
        array_2D = self.mask_no_alpha_pca.reshape(-1, self.mask_no_alpha_pca.shape[2])
        unique_colors = np.unique(array_2D, axis=0, return_counts=False)
        unique_colors = unique_colors[~np.all(unique_colors == [1, 1, 1], axis=1)]
        self.colors = self.update_color_list(unique_colors, self.colors)
        for color in self.colors:
            color_mask = np.all(self.mask_no_alpha_pca == np.array(color).reshape(1, 1, 3), axis=2)
            color_mask = np.reshape(color_mask, color_mask.shape[0]*color_mask.shape[1])
            score1 = self.scores[color_mask & ~np.isnan(self.scores[:,0]),self.idx1]
            score2 = self.scores[color_mask & ~np.isnan(self.scores[:,0]),self.idx2]
            dsp_coors = (self.dsp2mask_y(score2), self.dsp2mask_x(score1))
            self.alpha_dsp[dsp_coors] = self.app.button_layout.alpha_slider.get()
            self.mask_no_alpha_dsp[dsp_coors] = color
            self.mask_w_alpha_dsp[:,:,0:3] = self.mask_no_alpha_dsp
            self.mask_w_alpha_dsp[:,:,3] = self.alpha_dsp
        # array_2D = self.mask_w_alpha_dsp.reshape(-1, self.mask_w_alpha_dsp.shape[2])
        # unique_colors = unique_colors[~np.all(unique_colors == [1, 1, 1], axis=1)]
        self.im2_overlay.set_data(self.mask_w_alpha_dsp)


    ########## Converts DSP mask to pixels in score image ##########
    def dsp2scoreimg(self):
        #Get all unique colors from the mask
        array_2D = self.mask_no_alpha_dsp.reshape(-1, self.mask_no_alpha_dsp.shape[2])
        unique_colors = np.unique(array_2D, axis=0, return_counts=False)
        unique_colors = unique_colors[~np.all(unique_colors == [1, 1, 1], axis=1)]
        self.colors = self.update_color_list(unique_colors, self.colors)
        
        #calculate size of each "pixel" in density scatter plot
        res_x = 0.5*(self.bnds[0][1] - self.bnds[0][0])/(self.dsp_size-1) #range of scores covered by each pixel
        res_y = 0.5*(self.bnds[1][1] - self.bnds[1][0])/(self.dsp_size-1) #range of scores covered by each pixel

        for color in self.colors:
            color_mask = np.all(self.mask_no_alpha_dsp == np.array(color).reshape(1, 1, 3), axis=2)
            color_mask = np.invert(color_mask)
            coors = bm.get_rectangle_coordinates(color_mask)
            intervals = []
            for coor in coors:
                intervals.append([[self.mask2dsp_x(coor[1])-res_x, self.mask2dsp_x(coor[3])+res_x], [self.mask2dsp_y(coor[2])-res_y, self.mask2dsp_y(coor[0])+res_y]])
            intervals_arr = np.array(intervals).reshape((len(intervals), -1))
            
            bool_mask = np.zeros(self.scores.shape[0], dtype = bool)
            bool_mask = ((self.scores[:, self.idx1, None] >= intervals_arr[:, 0]) & (self.scores[:, self.idx1, None] <= intervals_arr[:, 1]) &
                         (self.scores[:, self.idx2, None] >= intervals_arr[:, 2]) & (self.scores[:, self.idx2, None] <= intervals_arr[:, 3])).any(axis=1)
            bool_mask_2D = np.reshape(bool_mask, [self.alpha_pca.shape[0], self.alpha_pca.shape[1]])
            self.mask_no_alpha_pca[bool_mask_2D] = color
            self.alpha_pca[bool_mask_2D] = self.app.button_layout.alpha_slider.get()
            self.mask_w_alpha_pca[:,:,0:3] = self.mask_no_alpha_pca
            self.mask_w_alpha_pca[:,:,3] = self.alpha_pca
        self.im1_overlay.set_data(self.mask_w_alpha_pca)


    def update_color_list(self, unique_values, color_list):
        # Convert the unique_values array to a list of tuples for easy comparison
        unique_tuples = [tuple(row) for row in unique_values]
        # Create a copy of the color_list to avoid modifying the original list while iterating
        updated_color_list = color_list.copy()

        # Check each row in unique_values
        for row in unique_tuples:
            if row not in updated_color_list:
                # If the row is not in color_list, add it
                updated_color_list.append(row)

        # Check each row in color_list
        for row in color_list:
            if tuple(row) not in unique_tuples:
                # If the row is not in unique_values, remove it
                updated_color_list.remove(row)

        return updated_color_list


    ########## Function to delete variables when window is closed ##########
    def quit_me(self):
        print('quit pca')
        self.window.destroy()
        del self.scores, self.loadings, self.fig, self.canvas, self.x_coors_pca,\
        self.y_coors_pca, self.dsp_size, self.mask_no_alpha_pca, self.alpha_pca,\
        self.mask_w_alpha_pca, self.mask_no_alpha_dsp,\
        self.alpha_dsp, self.mask_w_alpha_dsp



# import numpy as np
# import tkinter as tk
# import matplotlib
# matplotlib.use("TkAgg")
# from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
# from matplotlib.figure import Figure
# from matplotlib import gridspec
# from mpl_toolkits.axes_grid1 import make_axes_locatable
# import matplotlib.pyplot as plt
# import cv2 as cv
# from HSTI_Class import HSTI
# import Basic_Math as bm
# from fast_histogram import histogram2d
# import matplotlib.colors as colors
# import time
# from Loadings_window import loadings_window
# import HSTI as hsti


# class pca_window(tk.Frame):


#     ########## Setup window and initiate member variables ##########
#     def __init__(self, the_window, the_app):
#         self.x_coors_pca, self.y_coors_pca, self.x_coors_dsp, self.y_coors_dsp = [], [], [], []
#         self.dsp_size = 200
#         self.app = the_app
#         self.mask_pca = self.empty_rgba_mask(self.app.hsti.cube.shape[0], self.app.hsti.cube.shape[1])
#         self.bool_map_pca = np.zeros([self.app.hsti.cube.shape[0], self.app.hsti.cube.shape[1]], dtype=bool)
#         self.mask_no_alpha_pca = np.ones([self.app.hsti.cube.shape[0], self.app.hsti.cube.shape[1], 3], dtype=np.uint8)
#         self.alpha_pca = np.zeros([self.app.hsti.cube.shape[0], self.app.hsti.cube.shape[1]], dtype=np.uint8)
#         self.mask_w_alpha_pca = np.zeros([self.app.hsti.cube.shape[0], self.app.hsti.cube.shape[1], 4], dtype=np.uint8)
#         # # self.mask_no_alpha_dsp = np.ones([self.dsp_size, self.dsp_size, 3], dtype=np.uint8)
#         # self.alpha_dsp = np.zeros([self.dsp_size, self.dsp_size], dtype=np.uint8)
#         # self.mask_w_alpha_dsp = np.zeros([self.dsp_size, self.dsp_size, 4], dtype=np.uint8)
#         self.mask_dsp = self.empty_rgba_mask(self.dsp_size, self.dsp_size)
#         self.bool_map_dsp = np.zeros([self.dsp_size, self.dsp_size], dtype=bool)
#         self.colors = []
#         super().__init__(width = the_window.winfo_screenwidth(), height = 3*the_window.winfo_screenheight()//4)
#         self.bck = 'white'
#         self.canvas = tk.Canvas(self, width = the_window.winfo_screenwidth(), height = 3*the_window.winfo_screenheight()//4, background = self.bck)
#         self['bg'] = self.bck
#         self.parent = the_window
#         self.width = self.app.window_width//2
#         self.height = self.app.window_height//8
#         self.window = tk.Toplevel(self.parent, bg = self.bck)
#         self.window.title('PCA window')
#         self.DPI = 100
#         self.min_dim = min([self.app.window_width, self.app.window_height])
#         self.fig = Figure(figsize=(0.8*16*self.min_dim/900, 0.70*self.min_dim/100), dpi = self.DPI)
#         gs = gridspec.GridSpec(2, 2) #set size ratio of the subfigures
#         self.ax1 = self.fig.add_subplot(gs[:,0])
#         self.ax2 = self.fig.add_subplot(gs[:,1])

#         self.t1 = None
#         self.t2 = None

#         self.window.columnconfigure(0, weight = 1)
#         self.window.columnconfigure(1, weight = 2)
#         self.window.columnconfigure(2, weight = 2)
#         self.window.columnconfigure(3, weight = 2)
#         self.window.columnconfigure(4, weight = 2)
#         self.window.columnconfigure(5, weight = 1)

#         self.fig_TkAgg = FigureCanvasTkAgg(self.fig, master = self.window)
#         self.fig_TkAgg.draw()
#         self.fig_TkAgg.get_tk_widget().grid(row=0,column=0, columnspan = 6)
#         self.fig.canvas.mpl_connect('button_press_event', self.onclick)
#         self.fig.canvas.mpl_connect('button_release_event', self.onrelease)
#         self.fig.canvas.mpl_connect('motion_notify_event', self.onmove)

#         ########## Calculate and plot PCA of data_cube ##########
#         self.calculate_pca()
#         colormap = hsti.import_cm()
#         self.im1 = self.ax1.imshow(self.scores[:,0].reshape([self.app.hsti.cube.shape[0],self.app.hsti.cube.shape[1]]), interpolation = 'none', cmap = colormap)
#         # self.im1_overlay = self.ax1.imshow(self.mask_w_alpha_pca, interpolation = 'none', alpha = 1)
#         self.im1_overlay = self.ax1.imshow(self.mask_pca, interpolation = 'none')
#         self.ax1.set_title(f'Scores, PC {1}, {round(self.pct_expl_var[0],2)}%', pad = 10)
#         divider = make_axes_locatable(self.ax1)
#         cax = divider.append_axes('right', size='2%', pad=0.2)
#         cbar = self.fig.colorbar(self.im1, cax=cax, orientation='vertical')
#         self.idx1 = 0
#         self.idx2 = 1
#         self.im2 = self.density_scatter(self.scores[:,self.idx1], self.scores[:,self.idx2])
#         self.ax2.set_xlabel(f'Scores, PC {self.idx1+1}, {round(self.pct_expl_var[self.idx1],2)}%')
#         self.ax2.set_ylabel(f'Scores, PC {self.idx2+1}, {round(self.pct_expl_var[self.idx2],2)}%')
#         self.fig.tight_layout(pad=3)


#         ########## LIST BOXES + TITLES ##########
#         self.lb_score_img_title = tk.Label(self.window, text = "Score image", bg = self.bck)
#         self.lb_score_img_title.grid(row = 1, column = 1, columnspan = 2)
#         self.lb_score_img = tk.Listbox(self.window, height = 5, exportselection = False)
#         self.lb_score_img.grid(row = 2, column = 1, columnspan = 2, sticky = 'nsew')
#         self.lb_score_img.bind('<<ListboxSelect>>', self.update_scores)

#         self.lb_score_ax1_title = tk.Label(self.window, text = "Component, x-axis", bg = self.bck)
#         self.lb_score_ax1_title.grid(row = 1, column = 3)
#         self.lb_score_ax1 = tk.Listbox(self.window, height = 5, exportselection = False)
#         self.lb_score_ax1.grid(row = 2, column = 3, sticky = 'nsew')
#         self.lb_score_ax1.bind('<<ListboxSelect>>', self.update_dsp_x)

#         self.lb_score_ax2_title = tk.Label(self.window, text = "Component, y-axis", bg = self.bck)
#         self.lb_score_ax2_title.grid(row = 1, column = 4)
#         self.lb_score_ax2 = tk.Listbox(self.window, height = 5, exportselection = False)
#         self.lb_score_ax2.grid(row = 2, column = 4, sticky = 'nsew')
#         self.lb_score_ax2.bind('<<ListboxSelect>>', self.update_dsp_y)

#         options = []
#         for i in range(self.scores.shape[1]):
#             options.append(f'Scores, PC {i+1}, {round(self.pct_expl_var[i],2)}%')
#             self.lb_score_img.insert("end",options[-1])
#             self.lb_score_ax1.insert("end",options[-1])
#             self.lb_score_ax2.insert("end",options[-1])

#         # button for loadings plot
#         self.loadings_btn  = tk.Button(self.window, text = 'Plot loadings', bg = self.bck, command = lambda: loadings_window(self, self.app))
#         self.loadings_btn.grid(row = 3, column = 3)

#         self.window.protocol("WM_DELETE_WINDOW", self.quit_me)


#         ########## TOOLBAR ##########
#         # toolbarFrame = tk.Frame(master=self.window)
#         # toolbarFrame.grid(row=4,column=0, columnspan = 6)
#         # toolbar = NavigationToolbar2Tk(self.fig_TkAgg, toolbarFrame)

#     ########## Function for calculating PCA ##########
#     def calculate_pca(self):
#         print('Calculating PCA')
#         self.flat_cube = np.reshape(self.app.hsti.cube, [self.app.hsti.cube.shape[0]*self.app.hsti.cube.shape[1], self.app.hsti.cube.shape[2]])
#         nan_map = np.isnan(self.flat_cube) #form boolean array with true values everywhere a np.nan is encountered
#         if nan_map.any(): #If array_2D contains np.nan, do this
#             nan_row_idx = np.unique(np.argwhere(nan_map)[:,0]) #Find every row containing nan
#             for idx in nan_row_idx:
#                 nan_map[idx,:] = True #Expand the map to mark entire row
#             cov = np.cov((self.flat_cube[~nan_map].reshape(self.flat_cube.shape[0]-len(nan_row_idx), -1)).T) #exclude marked rows from cov calculation
#             del nan_row_idx
#         else:
#             cov = np.cov(self.flat_cube.T)
#         del nan_map
#         self.expl_var, self.loadings = np.linalg.eig(cov) #expl_var are the singular values, while P are the loadings of flat_cube
#         self.expl_var = np.real(self.expl_var)
#         self.loadings = np.real(self.loadings)
#         index = self.expl_var.argsort()[::-1]
#         self.expl_var = self.expl_var[index]
#         self.pct_expl_var = 100*self.expl_var/np.sum(self.expl_var)
#         self.loadings = self.loadings[:,index]
#         #calculate the percentage of explained variance for each of the eigen values - this corresponds to the contribution of each PC
#         self.expl_var_ratio = self.expl_var/np.sum(self.expl_var)
#         self.scores = self.flat_cube @ self.loadings

#     ########## Function for making empty 4-layer mask (rgbalpha) as a list of lists  ##########
#     def empty_rgba_mask(self, n_rows, n_cols):
#         rgba_mask = [
#             [
#                 [int(0), int(0), int(0), int(0)]
#                 for j in range(n_cols)
#             ]
#             for i in range(n_rows)
#         ]
#         return rgba_mask

#     ########## Thanks chatgpt - function for drawing line between two points using Bresenham's line algorithm ##########
#     def draw_line(self, img, x1, y1, x2, y2, thickness=1, value=1):
#         dx = abs(x2 - x1)
#         dy = abs(y2 - y1)
#         sx = -1 if x1 > x2 else 1
#         sy = -1 if y1 > y2 else 1
#         err = dx - dy

#         while True:
#             for i in range(-(thickness-1) // 2, (thickness-1) // 2 + 1):
#                 img[y1 + i, x1] = value
#                 img[y1, x1 + i] = value

#             if x1 == x2 and y1 == y2:
#                 break
#             e2 = 2 * err
#             if e2 > -dy:
#                 err -= dy
#                 x1 += sx
#             if e2 < dx:
#                 err += dx
#                 y1 += sy
#         return img

#     def fill_with_color(self, image_list_of_lists, bool_mask, rgba_color):
#         for i, row in enumerate(image_list_of_lists):
#             for j, pixel in enumerate(row):
#                 if bool_mask[i][j]:
#                     # Update the pixel values as desired
#                     image_list_of_lists[i][j] = rgba_color  # Set pixel to blue with full opacity
#         return image_list_of_lists 

#     ########## Update score image plot ##########
#     def update_scores(self, event):
#         idx = self.lb_score_img.curselection()[0]
#         self.im1.set_data(self.scores[:,idx].reshape([self.app.hsti.cube.shape[0],self.app.hsti.cube.shape[1]]))
#         self.im1.set_clim(vmin = np.nanmin(self.scores[:,idx]), vmax = np.nanmax(self.scores[:,idx]))
#         self.ax1.set_title(f'Scores, PC {idx+1}, {round(self.pct_expl_var[idx],2)}%', pad = 10)
#         self.fig_TkAgg.draw()
#         return

#     ########## Update density scatter plot, when new x-axis is selected ##########
#     def update_dsp_x(self, event):
#         self.ax2.cla()
#         self.idx1 = self.lb_score_ax1.curselection()[0]
#         self.cbar2.remove()
#         self.density_scatter(self.scores[:,self.idx1], self.scores[:,self.idx2])
#         self.ax2.set_xlabel(f'Scores, PC {self.idx1+1}, {round(self.pct_expl_var[self.idx1],2)}%')
#         self.ax2.set_ylabel(f'Scores, PC {self.idx2+1}, {round(self.pct_expl_var[self.idx2],2)}%')
#         # self.mask_no_alpha_dsp = np.ones([self.dsp_size, self.dsp_size, 3], dtype=np.uint8)
#         # self.alpha_dsp = np.zeros([self.dsp_size, self.dsp_size], dtype=np.uint8)
#         # self.mask_w_alpha_dsp = np.zeros([self.dsp_size, self.dsp_size, 4], dtype=np.uint8)
#         self.mask_dsp = self.empty_rgba_mask(self.dsp_size, self.dsp_size)
#         self.scoreimg2dsp()
#         self.display_mask_dsp()
#         return

#     ########## Update density scatter plot, when new y-axis is selected ##########
#     def update_dsp_y(self, event):
#         self.ax2.cla()
#         self.idx2 = self.lb_score_ax2.curselection()[0]
#         self.cbar2.remove()
#         self.density_scatter(self.scores[:,self.idx1], self.scores[:,self.idx2])
#         self.ax2.set_xlabel(f'Scores, PC {self.idx1+1}, {round(self.pct_expl_var[self.idx1],2)}%')
#         self.ax2.set_ylabel(f'Scores, PC {self.idx2+1}, {round(self.pct_expl_var[self.idx2],2)}%')
#         # self.mask_no_alpha_dsp = np.ones([self.dsp_size, self.dsp_size, 3], dtype=np.uint8)
#         # self.alpha_dsp = np.zeros([self.dsp_size, self.dsp_size], dtype=np.uint8)
#         # self.mask_w_alpha_dsp = np.zeros([self.dsp_size, self.dsp_size, 4], dtype=np.uint8)
#         self.mask_dsp = self.empty_rgba_mask(self.dsp_size, self.dsp_size)
#         self.scoreimg2dsp()
#         self.display_mask_dsp()
#         return

#     ########## Functions which registers mouse input ##########
#     def onclick(self, event):
#         if event.inaxes is not None:
#             self.ax = event.inaxes
#             if event.button == 1 or event.button == 3: # 1 =  Left click, 3 = Right click
#                 if self.ax == self.ax1:  #Only valid inside left pane
#                     self.x_coors_pca, self.y_coors_pca = [], []
#                     self.x_coors_pca.append(int(event.xdata))
#                     self.y_coors_pca.append(int(event.ydata))
#                 if self.ax == self.ax2:  #Only valid inside right pane
#                     self.x_coors_dsp, self.y_coors_dsp = [], []
#                     self.x_coors_dsp.append(self.dsp2mask_x(event.xdata))
#                     self.y_coors_dsp.append(self.dsp2mask_y(event.ydata))

#     ########## Functions which registers mouse input ##########
#     def onrelease(self, event):
#         if event.inaxes is not None:
#             self.ax = event.inaxes
#             if event.button == 1: # Left click
#                 if self.ax == self.ax1:
#                     self.x_coors_pca.append(int(event.xdata))
#                     self.y_coors_pca.append(int(event.ydata))
#                     self.paint_pca()
#                     # t1 = time.time()
#                     self.scoreimg2dsp()
#                     # t2 = time.time()
#                     # print(f'scoreimg2dsp: {t2-t1} s')
#                     self.display_mask_pca()
#                     self.display_mask_dsp()
#                 if self.ax == self.ax2:
#                     self.x_coors_dsp.append(self.dsp2mask_x(event.xdata))
#                     self.y_coors_dsp.append(self.dsp2mask_y(event.ydata))
#                     self.paint_dsp()
#                     # t1 = time.time()
#                     self.dsp2scoreimg()
#                     # t2 = time.time()
#                     # print(f'scoreimg2dsp: {t2-t1} s')
#                     self.display_mask_dsp()
#                     self.display_mask_pca()
#             if event.button == 3: # Right click
#                 if self.ax == self.ax1:
#                     self.x_coors_pca.append(int(event.xdata))
#                     self.y_coors_pca.append(int(event.ydata))
#                     self.erase_pca()
#                     self.scoreimg2dsp()
#                     self.display_mask_pca()
#                     self.display_mask_dsp()
#                 if self.ax == self.ax2:
#                     self.x_coors_dsp.append(self.dsp2mask_x(event.xdata))
#                     self.y_coors_dsp.append(self.dsp2mask_y(event.ydata))
#                     self.erase_dsp()
#                     self.dsp2scoreimg()
#                     self.display_mask_dsp()
#                     self.display_mask_pca()





#     ########## Functions which registers mouse input ##########
#     def onmove(self, event):
#         if event.inaxes is not None:
#             self.ax = event.inaxes
#             if event.button == 1: # Left click
#                 if self.ax == self.ax1:
#                     self.x_coors_pca.append(int(event.xdata))
#                     self.y_coors_pca.append(int(event.ydata))
#                     self.t1 = time.time()
#                     if self.t2 != None:
#                         print(f'time since last activation: {self.t1 - self.t2}')
#                     self.paint_pca()
#                     self.t2 = time.time()
#                     print(f'time in paint_pca: {self.t2 - self.t1}')
#                     # self.display_mask_pca()
#                 if self.ax == self.ax2:
#                     self.x_coors_dsp.append(self.dsp2mask_x(event.xdata))
#                     self.y_coors_dsp.append(self.dsp2mask_y(event.ydata))
#                     self.paint_dsp()
#                     self.display_mask_dsp()
#             if event.button == 3: # Right click
#                 if self.ax == self.ax1:
#                     self.x_coors_pca.append(int(event.xdata))
#                     self.y_coors_pca.append(int(event.ydata))
#                     self.erase_pca()
#                     self.display_mask_pca()
#                 if self.ax == self.ax2:
#                     self.x_coors_dsp.append(self.dsp2mask_x(event.xdata))
#                     self.y_coors_dsp.append(self.dsp2mask_y(event.ydata))
#                     self.erase_dsp()
#                     self.display_mask_dsp()

#     ########## Paint on score image based on registered coordinates ##########
#     def paint_pca(self):
#         if len(self.x_coors_pca) > 1:
#             # cv.line(self.mask_no_alpha_pca, (self.x_coors_pca[-2], self.y_coors_pca[-2]), (self.x_coors_pca[-1], self.y_coors_pca[-1]), self.app.viewer.specs[0]['color'], self.app.button_layout.radius_slider.get())
#             self.draw_line(self.bool_map_pca, self.x_coors_pca[-2], self.y_coors_pca[-2], self.x_coors_pca[-1], self.y_coors_pca[-1], self.app.button_layout.radius_slider.get(), True)
#             self.fill_with_color(self.mask_pca, self.bool_map_pca, self.app.viewer.specs[0]['color'] + (self.app.button_layout.alpha_slider.get(),))
#             # self.mask_w_alpha_pca[:,:,0:3] = self.mask_no_alpha_pca
#             # self.alpha_pca[np.sum(self.mask_no_alpha_pca, axis = 2) != 3] = self.app.button_layout.alpha_slider.get() #find all elements which do not have rgb value = (1,1,1)
#             # self.mask_w_alpha_pca[:,:,3] = self.alpha_pca
#             t1 = time.time()
#             self.display_mask_pca()
#             t2 = time.time()
#             print(f'time plotting: {t2 - t1}')
#         return

#     ########## Paint on DSP based on registered coordinates ##########
#     def paint_dsp(self):
#         if len(self.x_coors_dsp) > 1:
#             cv.line(self.mask_no_alpha_dsp, (self.x_coors_dsp[-2], self.y_coors_dsp[-2]), (self.x_coors_dsp[-1], self.y_coors_dsp[-1]), self.app.viewer.specs[0]['color'], self.app.button_layout.radius_slider.get())
#             self.mask_w_alpha_dsp[:,:,0:3] = self.mask_no_alpha_dsp
#             self.alpha_dsp[np.sum(self.mask_no_alpha_dsp, axis = 2) != 3] = self.app.button_layout.alpha_slider.get()
#             self.mask_w_alpha_dsp[:,:,3] = self.alpha_dsp
#             self.display_mask_dsp()
#         return

#     ########## Erases mask on score image based on registered coordinates ##########
#     def erase_pca(self):
#         if len(self.x_coors_pca) > 1:
#             cv.line(self.alpha_pca, (self.x_coors_pca[-2], self.y_coors_pca[-2]), (self.x_coors_pca[-1], self.y_coors_pca[-1]), 0, self.app.button_layout.radius_slider.get())
#             self.mask_w_alpha_pca[self.alpha_pca == 0] = 1
#             self.mask_w_alpha_pca[:,:,3] = self.alpha_pca
#             self.mask_no_alpha_pca = np.copy(self.mask_w_alpha_pca[:,:,:3])

#     ########## Erases mask on DSP based on registered coordinates ##########
#     def erase_dsp(self):
#         if len(self.x_coors_dsp) > 1:
#             self.mask_no_alpha_pca = np.ones([self.app.hsti.cube.shape[0], self.app.hsti.cube.shape[1], 3], dtype=np.uint8)
#             self.alpha_pca = np.zeros([self.app.hsti.cube.shape[0], self.app.hsti.cube.shape[1]], dtype=np.uint8)
#             self.mask_w_alpha_pca = np.zeros([self.app.hsti.cube.shape[0], self.app.hsti.cube.shape[1], 4], dtype=np.uint8)  
#             cv.line(self.alpha_dsp, (self.x_coors_dsp[-2], self.y_coors_dsp[-2]), (self.x_coors_dsp[-1], self.y_coors_dsp[-1]), 0, self.app.button_layout.radius_slider.get())
#             self.mask_w_alpha_dsp[self.alpha_dsp == 0] = 1
#             self.mask_w_alpha_dsp[:,:,3] = self.alpha_dsp
#             self.mask_no_alpha_dsp = np.copy(self.mask_w_alpha_dsp[:,:,:3])

#     ########## Display mask on both score image and DSP ##########
#     # def display_mask(self):
#     #     self.im1_overlay.set_data(self.mask_w_alpha_pca)
#     #     self.im2_overlay.set_data(self.mask_w_alpha_dsp)
#     #     self.fig_TkAgg.draw()

#     def display_mask_dsp(self):
#         self.im2_overlay.set_data(self.mask_dsp)
#         self.fig_TkAgg.draw()

#     def display_mask_pca(self):
#         self.im1_overlay.set_data(self.mask_pca)
#         # self.fig_TkAgg.draw()
#         self.fig.canvas.draw_idle()
#         # self.fig.canvas.restore_region(self.im1_overlay.axes.background)
#         # self.ax1.draw_artist(self.im1_overlay)
#         # self.fig.canvas.blit(self.im1_overlay.axes.bbox)

#     ########## Calculate and plot density scatter plot ##########
#     def density_scatter(self, X, Y):
#         # cmap = plt.get_cmap('viridis')
#         cmap = hsti.import_cm()
#         self.bnds = [[np.nanmin(X), np.nanmax(X)], [np.nanmin(Y), np.nanmax(Y)]]
#         h = histogram2d(X, Y, range=self.bnds, bins=self.dsp_size)
#         h = np.rot90(h)
#         self.im2 = self.ax2.imshow(h, extent=[self.bnds[0][0],self.bnds[0][1],self.bnds[1][0],self.bnds[1][1]], aspect='auto',\
#                    norm=colors.LogNorm(vmin=1, vmax=h.max()), cmap=cmap, interpolation = 'none')
#         self.im2_overlay = self.ax2.imshow(self.mask_dsp,\
#         extent=[self.bnds[0][0],self.bnds[0][1],self.bnds[1][0],self.bnds[1][1]], aspect='auto', alpha = 1)
#         self.ax2.set_title('Density scatter plot', pad = 10)
#         divider = make_axes_locatable(self.ax2)
#         cax = divider.append_axes('right', size='2%', pad=0.2)
#         self.cbar2 = self.fig.colorbar(self.im2, cax=cax, orientation='vertical', label='Number of points per pixel')

#     #Functions for calculating the coordinates of the DSP mask, based on cursor
#     #position. This is done by making a linear fit between the DSP axes and
#     #corresponding positions in a matrix.
#     def dsp2mask_x(self, x):
#         x_slope = (self.dsp_size-1)/(self.bnds[0][1] - self.bnds[0][0])
#         x_intercept = 0 - x_slope*self.bnds[0][0]
#         new_x = x_slope*x + x_intercept
#         return int(round(new_x)) #Result must be int, as it functions as mask index

#     def dsp2mask_y(self, y):
#         # The slope is negative, because the new y-axis runs in opposite direction
#         y_slope = -(self.dsp_size-1)/(self.bnds[1][1] - self.bnds[1][0])
#         y_intercept = (self.dsp_size-1) - y_slope*self.bnds[1][0]
#         new_y = y_slope*y + y_intercept
#         return int(round(new_y))

#     ########## Converting back from matrix indices to dsp coordinates ##########
#     def mask2dsp_x(self, x):
#         x_slope = (self.bnds[0][1] - self.bnds[0][0])/(self.dsp_size-1)
#         x_intercept = self.bnds[0][0]
#         new_x = x_slope*x + x_intercept
#         return new_x

#     def mask2dsp_y(self, y):
#         y_slope = -(self.bnds[1][1] - self.bnds[1][0])/(self.dsp_size-1)
#         y_intercept = self.bnds[1][1]
#         new_y = y_slope*y + y_intercept
#         return new_y

#     ########## Converts pixel positions in the score image to a mask in the DSP ##########
#     def scoreimg2dsp(self):
#         # self.mask_no_alpha_dsp = np.ones([self.dsp_size, self.dsp_size, 3], dtype=np.uint8)
#         # self.alpha_dsp = np.zeros([self.dsp_size, self.dsp_size], dtype=np.uint8)
#         # self.mask_w_alpha_dsp = np.zeros([self.dsp_size, self.dsp_size, 4], dtype=np.uint8)

#         # Extract unique colors in dsp mask. np.unique does not work as intended with axis = 2,
#         # so the array must be transposed and reshaped before it works.
#         t1 = time.time()
#         transposed_arr = np.transpose(self.mask_no_alpha_pca, (2, 0, 1)) 
#         reshaped_arr = transposed_arr.reshape(transposed_arr.shape[0], -1)
#         # The unique colors are stored along the columns. [1,1,1] will always be present as the background
#         self.colors = np.unique(reshaped_arr, axis=1)
#         del_idx = np.where((self.colors == 1).all(axis=0))[0]
#         if del_idx.size > 0:
#             self.colors = np.delete(self.colors, del_idx, axis=1)
#         t2 = time.time()

#         t6 = time.time()
#         mask_no_alpha_pca_lst = self.mask_no_alpha_pca.tolist()
#         t7 = time.time()
#         unique_colors = set()

#         # Iterate through the list of lists and add each RGB tuple to the set
#         for row in mask_no_alpha_pca_lst:
#             for pixel in row:
#                 unique_colors.add(tuple(pixel))  # Convert to tuple to make it hashable
#         t5 = time.time()
#         print(f'It took {t5-t2} s - array2list took {t7-t6} s')
#         print(unique_colors)



#         for i in range(self.colors.shape[1]):
#             t3 = time.time()
#             temp = self.mask_no_alpha_pca == self.colors[:,i]
#             temp = temp[:,:,0]
#             temp = np.reshape(temp, temp.shape[0]*temp.shape[1])
#             score1 = self.scores[temp,self.idx1]
#             score2 = self.scores[temp,self.idx2]
#             for j in range(len(score1)):
#                 if not np.isnan(score1[j]):
#                     dsp_coors = (self.dsp2mask_y(score2[j]), self.dsp2mask_x(score1[j]))
#                 self.alpha_dsp[dsp_coors] = self.app.button_layout.alpha_slider.get()
#                 self.mask_no_alpha_dsp[dsp_coors] = tuple(self.colors[:,i])
#                 self.mask_w_alpha_dsp[:,:,0:3] = self.mask_no_alpha_dsp
#                 self.mask_w_alpha_dsp[:,:,3] = self.alpha_dsp
#             self.im2_overlay.set_data(self.mask_dsp)
#             t4 = time.time()
#             print(f'time extracting colors: {t2-t1}, time performing loop: {t4-t3}')


#     ########## Converts DSP mask to pixels in score image ##########
#     def dsp2scoreimg(self):
#         # self.mask_no_alpha_pca = np.ones_like(self.app.hsti.mask_no_alpha, dtype=np.uint8)
#         # self.alpha_pca = np.zeros_like(self.app.hsti.alpha, dtype=np.uint8)
#         # self.mask_w_alpha_pca = np.zeros_like(self.app.hsti.mask_w_alpha, dtype=np.uint8)

#         # Extract unique colors in dsp mask. np.unique does not work as intended with axis = 2,
#         # so the array must be transposed and reshaped before it works.
#         transposed_arr = np.transpose(self.mask_no_alpha_dsp, (2, 0, 1)) 
#         reshaped_arr = transposed_arr.reshape(transposed_arr.shape[0], -1)
#         # The unique colors are stored along the columns. [1,1,1] will always be present as the background
#         self.colors = np.unique(reshaped_arr, axis=1)
#         del_idx = np.where((self.colors == 1).all(axis=0))[0]
#         if del_idx.size > 0:
#             self.colors = np.delete(self.colors, del_idx, axis=1)
#         res_x = 0.5*(self.bnds[0][1] - self.bnds[0][0])/(self.dsp_size-1) #range of scores covered by each pixel
#         res_y = 0.5*(self.bnds[1][1] - self.bnds[1][0])/(self.dsp_size-1) #range of scores covered by each pixel

#         for i in range(self.colors.shape[1]):
#             temp = self.mask_no_alpha_dsp == self.colors[:,i]
#             temp = temp[:,:,0]
#             temp = np.invert(temp)
#             coors = bm.get_rectangle_coordinates(temp)
#             intervals = []
#             for coor in coors:
#                 intervals.append([[self.mask2dsp_x(coor[1])-res_x, self.mask2dsp_x(coor[3])+res_x], [self.mask2dsp_y(coor[2])-res_y, self.mask2dsp_y(coor[0])+res_y]])
#             mask = np.zeros(self.scores.shape[0], dtype = bool)
#             for I in intervals:
#                 mask += (self.scores[:,self.idx1] >= I[0][0]) & (self.scores[:,self.idx1] <= I[0][1])\
#                 & (self.scores[:,self.idx2] >= I[1][0]) & (self.scores[:,self.idx2] <= I[1][1])
#             mask_2D = np.reshape(mask, [self.alpha_pca.shape[0], self.alpha_pca.shape[1]])
#             self.mask_no_alpha_pca[mask_2D] = tuple(self.colors[:,i])
#             self.alpha_pca[mask_2D] = self.app.button_layout.alpha_slider.get()
#             self.mask_w_alpha_pca[:,:,0:3] = self.mask_no_alpha_pca
#             self.mask_w_alpha_pca[:,:,3] = self.alpha_pca


#     ########## Function to delete variables when window is closed ##########
#     def quit_me(self):
#         print('quit pca')
#         self.window.destroy()
#         del self.scores, self.loadings, self.fig, self.canvas, self.x_coors_pca,\
#         self.y_coors_pca, self.dsp_size, self.mask_no_alpha_pca, self.alpha_pca,\
#         self.mask_w_alpha_pca, self.mask_no_alpha_dsp,\
#         self.alpha_dsp, self.mask_w_alpha_dsp