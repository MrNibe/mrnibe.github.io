import numpy as np
import Viewer_Canvas
import cv2 as cv
from scipy.ndimage import median_filter
import os

class HSTI():
    def __init__(self, cube = np.ones([1024, 768, 50])):
#        temp_img = np.ones([1024, 768, 50])
        self.raw_cube = cube
        self.cube = cube
        self.path = os.getcwd()
        self.x_axis_path = None
        self.calibrated_x_axis = False
        self.x_axis = np.linspace(1, self.cube.shape[2] + 1, self.cube.shape[2])
        self.x_axis_label = 'Band number [#]'
        self.camera_ID = None

        self.spatial_median_size = []
        self.savgol_w_length = []
        self.savgol_p_order = []
        self.savgol_deriv = []

        self.FPI_obj = None
        self.wl_cube = None
        self.ms_cube = None
        self.ref_spec = None
        self.ref_spec_from_selection = None

        #layers where the color information for the masks will be kept
        #The alpha channel is made separate because opencv does does not know what to do
        #when presented with four channel image.
        #1s are used as the eraser color, and the mask images are therefore initiated as matrices of ones.
        #This also means that the color (1,1,1) cannot be picked
        self.mask_no_alpha = np.ones([self.cube.shape[0], self.cube.shape[1], 3], dtype=np.uint8)
        self.alpha = np.zeros([self.cube.shape[0], self.cube.shape[1]], dtype=np.uint8)
        self.mask_w_alpha = np.zeros([self.cube.shape[0], self.cube.shape[1], 4], dtype=np.uint8)
        self.bool_map = np.zeros([self.cube.shape[0], self.cube.shape[1]])
