import tkinter as tk
from Button_Layout import Buttons
from Viewer_Canvas import Viewer
from PCA_window import pca_window
from Loadings_window import loadings_window
from HSTI_Class import HSTI
import numpy as np
from PIL import Image, ImageTk
import os
import screeninfo



class HSTI_viewer_app():
    def __init__(self, the_window):

        self.monitors = screeninfo.get_monitors()
        min_monitor = self.monitors[0].width * self.monitors[0].height
        min_monitor_idx = 0
        for idx, monitor in enumerate(self.monitors):
            if monitor.height*monitor.width < min_monitor:
                min_monitor_idx = idx
                min_monitor = self.monitors[idx].width * self.monitors[idx].height

        self.window_width = self.monitors[min_monitor_idx].width
        self.window_height = int(self.monitors[min_monitor_idx].height*0.9)
        self.hsti = HSTI()
        self.title = "Newtec HSTI Viewer"

        the_window.geometry(f"{self.window_width}x{self.window_height}+0+0")
        the_window.title(self.title)
        the_window.configure(bg = 'white')

        the_window.rowconfigure(0, weight=1)
        the_window.rowconfigure(1, weight=1)
        the_window.columnconfigure(0, weight=1)

        self.viewer = Viewer(the_window, self)
        self.viewer.canvas.grid(row = 0, column = 0)


        self.button_layout = Buttons(the_window, self)
        self.button_layout.grid(row = 1, column = 0, sticky = 'nsew')

        # self.viewer.display_band(self.hsti, 0)



########## Function which ensures the app closes ##########
def quit_me():
    print('quit')
    root.quit()
    root.destroy()


if __name__ == '__main__':
    root = tk.Tk()

    app = HSTI_viewer_app(root)

# Set icon of app
    ico = Image.open('data_files/viewer_logo.png')
    photo = ImageTk.PhotoImage(ico)
    root.wm_iconphoto(False, photo)

    root.protocol("WM_DELETE_WINDOW", quit_me)
    root.mainloop()
