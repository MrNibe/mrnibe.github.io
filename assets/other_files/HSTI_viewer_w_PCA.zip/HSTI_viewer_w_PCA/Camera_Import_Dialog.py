import tkinter as tk
from tkinter import simpledialog

class Camera_Dialog(tk.simpledialog.Dialog): #https://code-maven.com/slides/python/tk-customized-simple-dialog
    def __init__(self, parent, title):
        self.ID = None
        super().__init__(parent, title)

    def body(self, the_window):
        # print(type(frame)) # tkinter.Frame
        self.label = tk.Label(the_window, width=25, text="Pick camera ID")
        self.label.pack()

        OPTIONS = [
        "10_10_200_191",
        "10_10_200_22"
        ]
        self.selection = tk.StringVar(the_window)
        self.selection.set(OPTIONS[0]) # default value

        self.dropdown = tk.OptionMenu(the_window, self.selection, *OPTIONS)
        self.dropdown.pack()
        return the_window

    def ok_pressed(self):
        self.camera_ID = self.selection.get()
        self.destroy()

    def cancel_pressed(self):
        # print("cancel")
        self.destroy()

    def buttonbox(self):
        self.ok_button = tk.Button(self, text='OK', width=5, command=self.ok_pressed)
        self.ok_button.pack(side="left")
        cancel_button = tk.Button(self, text='Cancel', width=5, command=self.cancel_pressed)
        cancel_button.pack(side="right")
        self.bind("<Return>", lambda event: self.ok_pressed())
        self.bind("<Escape>", lambda event: self.cancel_pressed())
