import tkinter as tk
import matplotlib
matplotlib.use("TkAgg")
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
from matplotlib.figure import Figure
from matplotlib import gridspec
import matplotlib.patches as patch
from mpl_toolkits.axes_grid1 import make_axes_locatable
import matplotlib.pyplot as plt
import numpy as np
import cv2 as cv
import HSTI as hsti

class Viewer(tk.Frame):
    def __init__(self, the_window, the_app):
        super().__init__(width = the_window.winfo_screenwidth(), height = 3*the_window.winfo_screenheight()//4)
        self.canvas = tk.Canvas(self, width = the_window.winfo_screenwidth(), height = 3*the_window.winfo_screenheight()//4, background = 'white')
        self.app = the_app
        self.window = the_window
        self.x_coors, self.y_coors = [], []
        self.rects_positions = [(0,0)]
        self.current_band = 0
        # self.x_label = 'Band number [#]'
        # self.y_label = 'Intensity [a.u.]'
        self.initialize_plots()

    def initialize_plots(self):
            self.specs = [{'spectrum': [], 'color': (255, 0, 0),
                'rectangle': patch.Rectangle((0,0), 1, 1, facecolor = (1, 0, 0), \
                linewidth = 1, edgecolor = 'k')}]
            self.DPI = 100
            self.min_dim = min([self.app.window_width, self.app.window_height])
            plt.rc('xtick', labelsize=self.DPI/72*(self.min_dim/1440)*16)
            plt.rc('ytick', labelsize=self.DPI/72*(self.min_dim/1440)*16)
            plt.rc('axes', labelsize=self.DPI/72*(self.min_dim/1440)*16)
            plt.rc('lines', linewidth=self.DPI/72*(self.min_dim/1440)*3)
            plt.rc('legend', fontsize=self.DPI/72*(self.min_dim/1440)*12)
            plt.rc('figure', titlesize=self.DPI/72*(self.min_dim/1440)*24)
            plt.rc('axes', titlesize=self.DPI/72*(self.min_dim/1440)*24)
            self.colormap = hsti.import_cm()

            self.fig = Figure(figsize=(0.8*16*self.min_dim/900, 0.70*self.min_dim/100), dpi = self.DPI)
            gs = gridspec.GridSpec(6, 6) #set size ratio of the subfigures
            self.ax1 = self.fig.add_subplot(gs[:,0:3])
            self.ax2 = self.fig.add_subplot(gs[1:4,3:6])
            self.ax3 = self.fig.add_subplot(gs[4:,3:6])

            ########## Out matplotlib figure in Tk window ##########
            self.fig_TkAgg = FigureCanvasTkAgg(self.fig, master = self.window)
            self.fig_TkAgg.draw()
            self.fig_TkAgg.get_tk_widget().grid(row=0,column=0)
            self.fig.canvas.mpl_connect('button_press_event', self.onclick)
            self.fig.canvas.mpl_connect('button_release_event', self.onrelease)
            self.fig.canvas.mpl_connect('motion_notify_event', self.onmove)

            self.im1 = self.ax1.imshow(self.app.hsti.cube[:,:,self.current_band], interpolation = 'none', cmap = self.colormap)
            #im2 is used as the mask for drawing selections
            self.im2 = self.ax1.imshow(self.app.hsti.mask_w_alpha, interpolation = 'none', alpha = 1) # plot the gray scale image
            self.ax1.set_title('Band 0', pad = 10)
            divider = make_axes_locatable(self.ax1)
            cax = divider.append_axes('right', size='5%', pad=0.2)
            cbar = self.fig.colorbar(self.im1, cax=cax, orientation='vertical')

            self.plot_spec()
            self.ax3.set_axis_off()
            self.fig.tight_layout(pad=2.0, w_pad=5.0,)
            self.draw_rects()

    def display_band(self):
        self.im1.set_data(self.app.hsti.cube[:,:,self.current_band])
        if self.app.button_layout.C_clim.get():
            temp = self.app.button_layout.clim_slider.getValues()
            self.im1.set_clim(vmin = temp[0], vmax = temp[1])
        else:
            self.im1.set_clim(vmin = np.nanmin(self.app.hsti.cube[:,:,self.current_band]), vmax = np.nanmax(self.app.hsti.cube[:,:,self.current_band]))


        # if self.app.button_layout.c_x_axis.get():
        #     self.img_title = f'Mirror separation {np.round(self.app.hsti.x_axis[self.current_band], 2)} µm'
        # else:
        if self.app.hsti.calibrated_x_axis == True:
            self.ax1.set_title(f'{round(self.app.hsti.x_axis[self.current_band],2)}', pad = 10)
        else:
            self.ax1.set_title(f'Band {self.current_band + 1}', pad = 10)
        self.fig_TkAgg.draw()

    def display_mask(self):
        self.im2.set_data(self.app.hsti.mask_w_alpha)
        # self.fig_TkAgg.draw()
        self.fig.canvas.draw_idle()

    def reset_viewer(self):
        self.display_band()
        self.ax2.cla()
        self.x_coors, self.y_coors = [], []
    ########## Function which registers mouse input ##########
    def onclick(self, event):
        if event.inaxes is not None:
            self.ax = event.inaxes
            if event.button == 1 or event.button == 3: # 1 =  Left click, 3 = Right click
                if self.ax == self.ax1:  #Only valid inside left pane
                    self.x_coors, self.y_coors = [], []
                    self.x_coors.append(int(event.xdata))
                    self.y_coors.append(int(event.ydata))
                if self.ax == self.ax3: #When pressing color swatches
                    for idx, spec in enumerate(self.specs):
                        if ((event.xdata >= spec['rectangle'].get_x()) and (event.xdata <= spec['rectangle'].get_x() + spec['rectangle'].get_width())) \
                        and ((event.ydata >= spec['rectangle'].get_y()) and (event.ydata <= spec['rectangle'].get_y() + spec['rectangle'].get_height())):
                            self.specs.insert(0, self.specs.pop(idx))
                            self.plot_spec()
                            self.draw_rects()

    def onrelease(self, event):
        if event.inaxes is not None:
            self.ax = event.inaxes
            if event.button == 1: # Left click
                if self.ax == self.ax1:
                    self.x_coors.append(int(event.xdata))
                    self.y_coors.append(int(event.ydata))
                    self.paint()
                    self.calc_spec()
                    self.plot_spec()
                    self.draw_rects()
            if event.button == 3: # Right click
                if self.ax == self.ax1:
                    self.x_coors.append(int(event.xdata))
                    self.y_coors.append(int(event.ydata))
                    self.erase()
                    self.calc_spec()
                    self.plot_spec()
                    self.draw_rects()

    def onmove(self, event):
        if event.inaxes is not None:
            self.ax = event.inaxes
            if event.button == 1: # Left click
                if self.ax == self.ax1:
                    self.x_coors.append(int(event.xdata))
                    self.y_coors.append(int(event.ydata))
                    self.paint()
            if event.button == 3: # Right click
                if self.ax == self.ax1:
                    self.x_coors.append(int(event.xdata))
                    self.y_coors.append(int(event.ydata))
                    self.erase()

    def paint(self):
        if len(self.x_coors) > 1:
            cv.line(self.app.hsti.mask_no_alpha, (self.x_coors[-2], self.y_coors[-2]), (self.x_coors[-1], self.y_coors[-1]), self.specs[0]['color'], self.app.button_layout.radius_slider.get())
            cv.line(self.app.hsti.bool_map, (self.x_coors[-2], self.y_coors[-2]), (self.x_coors[-1], self.y_coors[-1]), 1, self.app.button_layout.radius_slider.get())
            self.app.hsti.mask_w_alpha[:,:,0:3] = self.app.hsti.mask_no_alpha
            self.app.hsti.alpha[self.app.hsti.bool_map == 1] = self.app.button_layout.alpha_slider.get()
            self.app.hsti.mask_w_alpha[:,:,3] = self.app.hsti.alpha
            self.display_mask()
        return

    def erase(self):
        if len(self.x_coors) > 1:
            cv.line(self.app.hsti.bool_map, (self.x_coors[-2], self.y_coors[-2]), (self.x_coors[-1], self.y_coors[-1]), 0, self.app.button_layout.radius_slider.get())
            self.app.hsti.alpha[self.app.hsti.bool_map == 0] = 0
            self.app.hsti.mask_w_alpha[:,:,3] = self.app.hsti.alpha
            self.display_mask()

    ########## Calculate average spectrum of masked areas ##########
    def calc_spec(self):
        new_specs = []
        if len(self.specs) > 0:
            self.specs[1:] = [x for x in self.specs[1:] if not (len(x['spectrum']) == 0)]
            for spec in self.specs:
                temp_mask = ((self.app.hsti.mask_no_alpha[:,:,0] == spec['color'][0]) & (self.app.hsti.mask_no_alpha[:,:,1] == spec['color'][1])\
                & (self.app.hsti.mask_no_alpha[:,:,2] == spec['color'][2]) & (self.app.hsti.bool_map == 1))
                if sum(sum(temp_mask)) > 0:
                    # if self.app.button_layout.c_std.get():
                    #     spec['spectrum'] = np.mean(self.app.hsti.cube_std[temp_mask,:], axis = 0)
                    # elif self.app.button_layout.c_f0.get():
                    #     spec['spectrum'] = np.mean(self.app.hsti.cube_f0[temp_mask,:], axis = 0)
                    # else:
                    spec['spectrum'] = np.nanmean(self.app.hsti.cube[temp_mask,:], axis = 0)
                    new_specs.append(spec)
            if new_specs == []:
                new_specs = [{'spectrum': [], 'color': self.specs[0]['color'],
                'rectangle': patch.Rectangle((0,0), 1, 1, facecolor = [rgb/255 for rgb in self.specs[0]['color']], \
                linewidth = 1, edgecolor = 'k')}]
        self.specs = new_specs

    def plot_spec(self):
        self.ax2.cla()
        z_order = np.flip(np.arange(len(self.specs)))
        for (spec, z) in zip(self.specs, z_order):
            if len(spec['spectrum']) == len(self.app.hsti.x_axis):
                clr = tuple(rgb/255 for rgb in spec['color'])  #Normalized rgb values
                self.ax2.plot(self.app.hsti.x_axis, spec['spectrum'], color = clr, zorder = z)
        self.ax2.set_xlim([self.app.hsti.x_axis[0], self.app.hsti.x_axis[-1]])
        self.ax2.grid(True)
        self.ax2.set_title('Mean spectra based on selection', pad = 10)
        self.ax2.set(xlabel = self.app.hsti.x_axis_label, ylabel = 'Intensity [a.u.]')
        self.fig_TkAgg.draw()

    def draw_rects(self):
        self.ax3.cla()
        col_w = 5
        row_h = 1
        n_cols = 4
        n_rows = 3
        counter = 0
        size = 1
        for rect in self.specs:
            col_idx = np.mod(counter, n_cols)
            row_idx = counter//n_cols
            rect['rectangle'].xy = (col_w*col_idx, row_h*row_idx)
            self.ax3.add_patch(rect['rectangle'])
            self.ax3.text(rect['rectangle'].xy[0] + 1.25*size, rect['rectangle'].xy[1] + 0.25*size, str(rect['color']), fontsize=self.DPI/72*(self.min_dim/1440)*10)
            counter += 1

        self.ax3.axis('scaled')
        self.ax3.set_ylim([-0.1,4])
        self.ax3.set_xlim([-0.1,20])
        self.ax3.set_axis_off()
        self.fig_TkAgg.draw()
